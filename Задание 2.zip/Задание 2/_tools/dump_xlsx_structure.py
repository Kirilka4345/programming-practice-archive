from __future__ import annotations

from pathlib import Path
from typing import Any

from openpyxl import load_workbook


ROOT = Path(__file__).resolve().parents[1]
VARIANT_DIR = ROOT / "Вариант 12" / "Модуль 1" / "import"
OUT_FILE = ROOT / "_extracted" / "xlsx_structure.txt"


def cell_to_str(v: Any) -> str:
    if v is None:
        return ""
    return str(v)


def dump_xlsx(path: Path, max_rows: int = 6, max_cols: int = 20) -> list[str]:
    wb = load_workbook(path, data_only=True)
    lines: list[str] = []
    lines.append(f"### FILE: {path.relative_to(ROOT).as_posix()}")
    lines.append(f"SHEETS: {', '.join(wb.sheetnames)}")
    for sn in wb.sheetnames:
        ws = wb[sn]
        # compute used range-ish
        rows = []
        for r_idx, row in enumerate(ws.iter_rows(values_only=True), start=1):
            if r_idx > max_rows:
                break
            rows.append(list(row)[:max_cols])
        lines.append(f"\n-- SHEET: {sn} --")
        lines.append(f"max_row: {ws.max_row}, max_column: {ws.max_column}")
        for i, r in enumerate(rows, start=1):
            lines.append(f"row{i}: " + " | ".join(cell_to_str(v) for v in r))
    lines.append("")
    return lines


def main() -> None:
    (ROOT / "_extracted").mkdir(exist_ok=True)
    files = [
        VARIANT_DIR / "Tovar.xlsx",
        VARIANT_DIR / "user_import.xlsx",
        VARIANT_DIR / "Заказ_import.xlsx",
        VARIANT_DIR / "Пункты выдачи_import.xlsx",
    ]
    lines: list[str] = []
    for f in files:
        if not f.exists():
            lines.append(f"### FILE: {f.relative_to(ROOT).as_posix()}")
            lines.append("MISSING\n")
            continue
        lines.extend(dump_xlsx(f))
    OUT_FILE.write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()

