from __future__ import annotations

from pathlib import Path
from zipfile import ZipFile

import docx
from openpyxl import load_workbook


ROOT = Path(__file__).resolve().parents[1]
VARIANT_DIR = ROOT / "Вариант 12"
OUT_DIR = ROOT / "_extracted"


def dump_docx(path: Path) -> str:
    d = docx.Document(path)
    lines: list[str] = []
    lines.append(f"### FILE: {path.relative_to(ROOT).as_posix()}")
    lines.append("## PARAGRAPHS")
    for p in d.paragraphs:
        t = (p.text or "").strip()
        if t:
            lines.append(t)
    if d.tables:
        lines.append("## TABLES")
    for ti, table in enumerate(d.tables, 1):
        lines.append(f"-- TABLE {ti} --")
        for row in table.rows:
            cells = [(c.text or "").replace("\n", " ").strip() for c in row.cells]
            if any(cells):
                lines.append(" | ".join(cells))
    return "\n".join(lines)

def extract_docx_media(docx_path: Path, target_dir: Path) -> list[Path]:
    """
    Extract embedded media (images) from DOCX (zip) to target_dir.
    Returns list of extracted file paths.
    """
    extracted: list[Path] = []
    target_dir.mkdir(parents=True, exist_ok=True)
    with ZipFile(docx_path) as z:
        for name in z.namelist():
            if not name.startswith("word/media/"):
                continue
            # keep original filename (e.g. image1.png)
            out_path = target_dir / Path(name).name
            with z.open(name) as src, out_path.open("wb") as dst:
                dst.write(src.read())
            extracted.append(out_path)
    return extracted


def xlsx_preview(path: Path, max_rows: int = 3) -> None:
    wb = load_workbook(path, data_only=True)
    print("sheets:", wb.sheetnames)
    for name in wb.sheetnames:
        ws = wb[name]
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            print(" sheet:", name, "(empty)")
            continue
        header = list(rows[0])
        data = rows[1 : 1 + max_rows]
        n_rows = max(0, len(rows) - 1)
        print(" sheet:", name, "rows:", n_rows, "cols:", len(header))
        print("  columns:", header)
        print("  head:")
        for r in data:
            print("   ", list(r))


def main() -> None:
    OUT_DIR.mkdir(exist_ok=True)

    docx_paths = [
        VARIANT_DIR / "Вариант 12.docx",
        VARIANT_DIR / "Модуль 1" / "Прил_1_ОЗ_КОД 09.02.07-2-2026-М1.docx",
        VARIANT_DIR / "Модуль 2" / "Прил_3_ОЗ_КОД 09.02.07-2-2026-М2.docx",
    ]

    for p in docx_paths:
        if p.exists():
            txt = dump_docx(p)
            out_path = OUT_DIR / (p.name + ".txt")
            out_path.write_text(txt, encoding="utf-8")
            print("wrote", out_path.relative_to(ROOT))

            media_dir = OUT_DIR / "docx_media" / p.stem
            media = extract_docx_media(p, media_dir)
            if media:
                print(" extracted media:", len(media), "->", media_dir.relative_to(ROOT))
            else:
                print(" extracted media: 0")
        else:
            print("missing", p.relative_to(ROOT))

    xlsx_paths = [
        VARIANT_DIR / "Модуль 1" / "import" / "Tovar.xlsx",
        VARIANT_DIR / "Модуль 1" / "import" / "user_import.xlsx",
        VARIANT_DIR / "Модуль 1" / "import" / "Заказ_import.xlsx",
        VARIANT_DIR / "Модуль 1" / "import" / "Пункты выдачи_import.xlsx",
    ]

    print("\n### XLSX SUMMARY")
    for xp in xlsx_paths:
        if not xp.exists():
            print("\nmissing:", xp.relative_to(ROOT).as_posix())
            continue
        print("\nFILE:", xp.relative_to(ROOT).as_posix())
        xlsx_preview(xp)


if __name__ == "__main__":
    main()

