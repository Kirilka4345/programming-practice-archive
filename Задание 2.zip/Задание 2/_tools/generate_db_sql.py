from __future__ import annotations

import datetime as dt
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from openpyxl import load_workbook


ROOT = Path(__file__).resolve().parents[1]
IMPORT_DIR = ROOT / "Вариант 12" / "Модуль 1" / "import"
DB_DIR = ROOT / "database"

DB_NAME = "Posudarushka"
DB_COLLATION = "Cyrillic_General_100_CI_AS_SC"


def nstr(value: Any) -> str:
    """SQL NVARCHAR literal (N'...') or NULL."""
    if value is None:
        return "NULL"
    s = str(value).replace("'", "''")
    return f"N'{s}'"


def sql_date(value: Any) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, dt.datetime):
        value = value.date()
    if isinstance(value, dt.date):
        return f"'{value.isoformat()}'"
    return f"'{str(value)}'"


def normalize_date(value: Any) -> dt.date:
    """
    Normalize dates coming from Excel. Handles:
    - datetime/date values
    - strings like '2025-04-20' or '30.02.2025' (clamps invalid day to last day of month)
    """
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value

    s = str(value).strip()
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d.%m.%y"):
        try:
            return dt.datetime.strptime(s, fmt).date()
        except ValueError:
            pass

    m = re.match(r"^\s*(\d{1,2})\.(\d{1,2})\.(\d{4})\s*$", s)
    if m:
        day = int(m.group(1))
        month = int(m.group(2))
        year = int(m.group(3))
        # clamp day to last day of month
        if month < 1:
            month = 1
        if month > 12:
            month = 12
        last_day = (dt.date(year + (month == 12), 1 if month == 12 else month + 1, 1) - dt.timedelta(days=1)).day
        day = max(1, min(day, last_day))
        return dt.date(year, month, day)

    # fallback: today
    return dt.date.today()


def sql_decimal(value: Any) -> str:
    if value is None or value == "":
        return "NULL"
    if isinstance(value, (int, float)):
        return str(value)
    s = str(value).strip()
    s = s.replace(" ", "").replace(",", ".")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    return m.group(0) if m else "NULL"


def load_sheet_rows(path: Path, sheet_name: str = "Лист1") -> list[list[Any]]:
    wb = load_workbook(path, data_only=True)
    ws = wb[sheet_name]
    return [list(r) for r in ws.iter_rows(values_only=True)]


@dataclass(frozen=True)
class ProductRow:
    article: str
    name: str
    unit: str
    price_rub: float
    supplier: str
    manufacturer: str
    category: str
    discount_fraction: float
    stock_qty: int
    description: str
    photo_file: str | None


@dataclass(frozen=True)
class UserRow:
    role: str
    full_name: str
    login: str
    password: str


@dataclass(frozen=True)
class PickupPointRow:
    postal_code: str
    city: str
    street: str
    house: str


@dataclass(frozen=True)
class OrderRow:
    order_number: int
    items_raw: str
    order_date: dt.date
    delivery_date: dt.date
    pickup_point_ref: int
    customer_full_name: str
    receive_code: int
    status: str


def parse_products() -> list[ProductRow]:
    rows = load_sheet_rows(IMPORT_DIR / "Tovar.xlsx")
    header = rows[0]
    idx = {str(h).strip(): i for i, h in enumerate(header)}

    # Scan for available images
    existing_images = {f.name.lower() for f in IMPORT_DIR.glob("*.jpg")}
    # Also check without extension or different case
    
    def find_image(art: str) -> str | None:
        # 1. Try numeric extraction from article (e.g. PS012 -> 12 -> 12.jpg)
        m = re.search(r"\d+", art)
        if m:
            num = int(m.group(0))
            candidate = f"{num}.jpg"
            if candidate.lower() in existing_images:
                return candidate
        return None

    def v(r: list[Any], col: str) -> Any:
        return r[idx[col]] if col in idx else None

    out: list[ProductRow] = []
    for r in rows[1:]:
        if not r or r[0] is None:
            continue
            
        article = str(v(r, "Артикул")).strip()
        photo_val = v(r, "Фото")
        photo_file = str(photo_val).strip() if photo_val else None
        
        # Smart image fallback
        if not photo_file:
            photo_file = find_image(article)
        elif photo_file.lower() not in existing_images:
             # Maybe path issues in excel? check if exists
             pass

        out.append(
            ProductRow(
                article=article,
                name=str(v(r, "Наименование товара")).strip(),
                unit=str(v(r, "Единица измерения")).strip(),
                price_rub=float(sql_decimal(v(r, "Цена"))),
                supplier=str(v(r, "Поставщик")).strip(),
                manufacturer=str(v(r, "Производитель")).strip(),
                category=str(v(r, "Категория товара")).strip(),
                discount_fraction=float(v(r, "Действующая скидка") or 0),
                stock_qty=int(v(r, "Кол-во на складе") or 0),
                description=str(v(r, "Описание товара") or "").strip(),
                photo_file=photo_file,
            )
        )
    return out


def parse_users() -> list[UserRow]:
    rows = load_sheet_rows(IMPORT_DIR / "user_import.xlsx")
    header = rows[0]
    idx = {str(h).strip(): i for i, h in enumerate(header)}

    def v(r: list[Any], col: str) -> Any:
        return r[idx[col]] if col in idx else None

    out: list[UserRow] = []
    for r in rows[1:]:
        if not r or r[0] is None:
            continue
        role = str(v(r, "Роль сотрудника")).strip()
        # In provided data роль клиента названа иначе; нормализуем до одной роли.
        if role == "Авторизированный клиент":
            role = "Клиент"
        out.append(
            UserRow(
                role=role,
                full_name=str(v(r, "ФИО")).strip(),
                login=str(v(r, "Логин")).strip(),
                password=str(v(r, "Пароль")).strip(),
            )
        )
    return out


def parse_pickup_points() -> list[PickupPointRow]:
    rows = load_sheet_rows(IMPORT_DIR / "Пункты выдачи_import.xlsx")
    out: list[PickupPointRow] = []
    for r in rows:
        raw = (r[0] or "").strip() if r and r[0] else ""
        if not raw:
            continue
        parts = [p.strip() for p in raw.split(",")]
        out.append(
            PickupPointRow(
                postal_code=parts[0] if len(parts) > 0 else "",
                city=parts[1] if len(parts) > 1 else "",
                street=parts[2] if len(parts) > 2 else "",
                house=parts[3] if len(parts) > 3 else "",
            )
        )
    return out


def parse_orders() -> list[OrderRow]:
    rows = load_sheet_rows(IMPORT_DIR / "Заказ_import.xlsx")
    header = rows[0]
    idx = {str(h).strip(): i for i, h in enumerate(header) if h and str(h).strip()}

    def v(r: list[Any], col: str) -> Any:
        return r[idx[col]] if col in idx else None

    out: list[OrderRow] = []
    for r in rows[1:]:
        if not r or r[0] is None:
            continue
        od = v(r, "Дата заказа")
        dd = v(r, "Дата доставки")
        od = normalize_date(od)
        dd = normalize_date(dd)
        if dd < od:
            dd = od
        out.append(
            OrderRow(
                order_number=int(v(r, "Номер заказа")),
                items_raw=str(v(r, "Артикул заказа")).strip(),
                order_date=od,
                delivery_date=dd,
                pickup_point_ref=int(v(r, "Адрес пункта выдачи")),
                customer_full_name=str(v(r, "ФИО авторизированного клиента")).strip(),
                receive_code=int(v(r, "Код для получения")),
                status=str(v(r, "Статус заказа")).strip(),
            )
        )
    return out


def parse_items(items_raw: str) -> list[tuple[str, int]]:
    parts = [p.strip() for p in str(items_raw).split(",") if p and str(p).strip()]
    out: list[tuple[str, int]] = []
    i = 0
    while i + 1 < len(parts):
        art = parts[i]
        try:
            qty = int(parts[i + 1])
        except ValueError:
            qty = 1
        out.append((art, qty))
        i += 2
    return out


def distinct(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for v in values:
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out


def write_create_sql(path: Path) -> None:
    sql = f"""\
/* Auto-generated. DB: {DB_NAME} */

SET NOCOUNT ON;

IF DB_ID(N'{DB_NAME}') IS NULL
BEGIN
  CREATE DATABASE [{DB_NAME}] COLLATE {DB_COLLATION};
END
GO

USE [{DB_NAME}];
GO

IF OBJECT_ID(N'dbo.Role', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Role (
    RoleId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Role PRIMARY KEY,
    Name NVARCHAR(50) NOT NULL CONSTRAINT UQ_Role_Name UNIQUE
  );
END
GO

IF OBJECT_ID(N'dbo.[User]', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.[User] (
    UserId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_User PRIMARY KEY,
    RoleId INT NOT NULL CONSTRAINT FK_User_Role REFERENCES dbo.Role(RoleId),
    FullName NVARCHAR(200) NOT NULL,
    Login NVARCHAR(200) NOT NULL CONSTRAINT UQ_User_Login UNIQUE,
    PasswordHash NVARCHAR(200) NOT NULL
  );
END
GO

IF OBJECT_ID(N'dbo.Supplier', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Supplier (
    SupplierId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Supplier PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL CONSTRAINT UQ_Supplier_Name UNIQUE
  );
END
GO

IF OBJECT_ID(N'dbo.Manufacturer', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Manufacturer (
    ManufacturerId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Manufacturer PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL CONSTRAINT UQ_Manufacturer_Name UNIQUE
  );
END
GO

IF OBJECT_ID(N'dbo.Category', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Category (
    CategoryId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Category PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL CONSTRAINT UQ_Category_Name UNIQUE
  );
END
GO

IF OBJECT_ID(N'dbo.Product', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Product (
    ProductId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Product PRIMARY KEY,
    Article NVARCHAR(50) NOT NULL CONSTRAINT UQ_Product_Article UNIQUE,
    Name NVARCHAR(300) NOT NULL,
    Unit NVARCHAR(50) NOT NULL,
    PriceRub DECIMAL(18,2) NOT NULL CONSTRAINT CK_Product_Price CHECK (PriceRub >= 0),
    SupplierId INT NOT NULL CONSTRAINT FK_Product_Supplier REFERENCES dbo.Supplier(SupplierId),
    ManufacturerId INT NOT NULL CONSTRAINT FK_Product_Manufacturer REFERENCES dbo.Manufacturer(ManufacturerId),
    CategoryId INT NOT NULL CONSTRAINT FK_Product_Category REFERENCES dbo.Category(CategoryId),
    DiscountPercent DECIMAL(5,2) NOT NULL CONSTRAINT CK_Product_Discount CHECK (DiscountPercent >= 0 AND DiscountPercent <= 99.99),
    StockQty INT NOT NULL CONSTRAINT CK_Product_Stock CHECK (StockQty >= 0),
    Description NVARCHAR(MAX) NULL,
    ImagePath NVARCHAR(400) NULL
  );
END
GO

IF OBJECT_ID(N'dbo.PickupPoint', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.PickupPoint (
    PickupPointId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_PickupPoint PRIMARY KEY,
    PostalCode NVARCHAR(20) NOT NULL,
    City NVARCHAR(100) NOT NULL,
    Street NVARCHAR(200) NOT NULL,
    House NVARCHAR(50) NOT NULL,
    FullAddress AS (LTRIM(RTRIM(CONCAT(PostalCode, N', ', City, N', ', Street, N', ', House))))
  );
END
GO

IF OBJECT_ID(N'dbo.OrderStatus', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.OrderStatus (
    OrderStatusId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_OrderStatus PRIMARY KEY,
    Name NVARCHAR(50) NOT NULL CONSTRAINT UQ_OrderStatus_Name UNIQUE
  );
END
GO

IF OBJECT_ID(N'dbo.[Order]', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.[Order] (
    OrderId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Order PRIMARY KEY,
    OrderNumber INT NOT NULL CONSTRAINT UQ_Order_OrderNumber UNIQUE,
    CustomerId INT NOT NULL CONSTRAINT FK_Order_User REFERENCES dbo.[User](UserId),
    PickupPointId INT NOT NULL CONSTRAINT FK_Order_PickupPoint REFERENCES dbo.PickupPoint(PickupPointId),
    OrderStatusId INT NOT NULL CONSTRAINT FK_Order_Status REFERENCES dbo.OrderStatus(OrderStatusId),
    OrderDate DATE NOT NULL,
    DeliveryDate DATE NOT NULL,
    ReceiveCode INT NOT NULL,
    CONSTRAINT CK_Order_Dates CHECK (DeliveryDate >= OrderDate)
  );
END
GO

IF OBJECT_ID(N'dbo.OrderItem', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.OrderItem (
    OrderItemId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_OrderItem PRIMARY KEY,
    OrderId INT NOT NULL CONSTRAINT FK_OrderItem_Order REFERENCES dbo.[Order](OrderId) ON DELETE CASCADE,
    ProductId INT NOT NULL CONSTRAINT FK_OrderItem_Product REFERENCES dbo.Product(ProductId),
    Quantity INT NOT NULL CONSTRAINT CK_OrderItem_Qty CHECK (Quantity > 0),
    CONSTRAINT UQ_OrderItem_Order_Product UNIQUE (OrderId, ProductId)
  );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Product_Name' AND object_id = OBJECT_ID(N'dbo.Product'))
  CREATE INDEX IX_Product_Name ON dbo.Product(Name);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Order_OrderDate' AND object_id = OBJECT_ID(N'dbo.[Order]'))
  CREATE INDEX IX_Order_OrderDate ON dbo.[Order](OrderDate);
GO
"""
    # Write with BOM to make Windows tooling reliably detect UTF-8.
    path.write_text(sql, encoding="utf-8-sig")


def write_seed_sql(path: Path) -> None:
    products = parse_products()
    users = parse_users()
    pickup_points = parse_pickup_points()
    orders = parse_orders()

    statuses = distinct([o.status for o in orders] or ["Создан"])
    suppliers = distinct([p.supplier for p in products])
    manufacturers = distinct([p.manufacturer for p in products])
    categories = distinct([p.category for p in products])

    # Add any missing users from orders as clients
    users_by_fullname = {u.full_name: u for u in users}
    auto_clients: list[UserRow] = []
    for o in orders:
        if o.customer_full_name not in users_by_fullname:
            slug = re.sub(r"\s+", ".", o.customer_full_name.strip().lower())
            slug = re.sub(r"[^a-zа-я0-9\.]", "", slug)
            login = f"{slug}@client.local"
            password = "client"
            u = UserRow(role="Клиент", full_name=o.customer_full_name, login=login, password=password)
            users_by_fullname[o.customer_full_name] = u
            auto_clients.append(u)

    all_users = users + auto_clients

    # Ensure products referenced by orders exist
    products_by_article = {p.article: p for p in products}
    missing_articles: set[str] = set()
    for o in orders:
        for art, _qty in parse_items(o.items_raw):
            if art and art not in products_by_article:
                missing_articles.add(art)

    for art in sorted(missing_articles):
        products.append(
            ProductRow(
                article=art,
                name=f"Товар {art}",
                unit="шт.",
                price_rub=0.0,
                supplier=suppliers[0] if suppliers else "Поставщик (не указан)",
                manufacturer=manufacturers[0] if manufacturers else "Производитель (не указан)",
                category=categories[0] if categories else "Категория (не указана)",
                discount_fraction=0.0,
                stock_qty=0,
                description="Добавлен автоматически, потому что встречается в заказах.",
                photo_file=None,
            )
        )
        products_by_article[art] = products[-1]

    # Refresh sets after potential adds
    suppliers = distinct([p.supplier for p in products])
    manufacturers = distinct([p.manufacturer for p in products])
    categories = distinct([p.category for p in products])

    lines: list[str] = []
    lines.append(f"/* Auto-generated seed for {DB_NAME}. */")
    lines.append("SET NOCOUNT ON;")
    lines.append("SET XACT_ABORT ON;")
    lines.append(f"USE [{DB_NAME}];\n")
    lines.append("BEGIN TRAN;\n")

    # Always seed from a clean state to keep identity IDs stable for imports.
    lines.append("-- Clean existing data (safe for учебный проект)")
    lines.append("DELETE FROM dbo.OrderItem;")
    lines.append("DELETE FROM dbo.[Order];")
    lines.append("DELETE FROM dbo.Product;")
    lines.append("DELETE FROM dbo.PickupPoint;")
    lines.append("DELETE FROM dbo.[User];")
    lines.append("DELETE FROM dbo.OrderStatus;")
    lines.append("DELETE FROM dbo.Category;")
    lines.append("DELETE FROM dbo.Manufacturer;")
    lines.append("DELETE FROM dbo.Supplier;")
    lines.append("DELETE FROM dbo.Role;")
    lines.append("")
    lines.append("DBCC CHECKIDENT('dbo.[User]', RESEED, 0);")
    lines.append("DBCC CHECKIDENT('dbo.Supplier', RESEED, 0);")
    lines.append("DBCC CHECKIDENT('dbo.Manufacturer', RESEED, 0);")
    lines.append("DBCC CHECKIDENT('dbo.Category', RESEED, 0);")
    lines.append("DBCC CHECKIDENT('dbo.Product', RESEED, 0);")
    lines.append("DBCC CHECKIDENT('dbo.PickupPoint', RESEED, 0);")
    lines.append("DBCC CHECKIDENT('dbo.OrderStatus', RESEED, 0);")
    lines.append("DBCC CHECKIDENT('dbo.[Order]', RESEED, 0);")
    lines.append("DBCC CHECKIDENT('dbo.OrderItem', RESEED, 0);")
    lines.append("")

    for role in ["Администратор", "Менеджер", "Клиент"]:
        lines.append(
            "IF NOT EXISTS (SELECT 1 FROM dbo.Role WHERE Name = {name}) "
            "INSERT INTO dbo.Role(Name) VALUES ({name});".format(name=nstr(role))
        )
    lines.append("")

    for st in statuses:
        lines.append(
            "IF NOT EXISTS (SELECT 1 FROM dbo.OrderStatus WHERE Name = {name}) "
            "INSERT INTO dbo.OrderStatus(Name) VALUES ({name});".format(name=nstr(st))
        )
    lines.append("")

    for s in suppliers:
        lines.append(
            "IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = {name}) "
            "INSERT INTO dbo.Supplier(Name) VALUES ({name});".format(name=nstr(s))
        )
    lines.append("")

    for m in manufacturers:
        lines.append(
            "IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = {name}) "
            "INSERT INTO dbo.Manufacturer(Name) VALUES ({name});".format(name=nstr(m))
        )
    lines.append("")

    for c in categories:
        lines.append(
            "IF NOT EXISTS (SELECT 1 FROM dbo.Category WHERE Name = {name}) "
            "INSERT INTO dbo.Category(Name) VALUES ({name});".format(name=nstr(c))
        )
    lines.append("")

    for u in all_users:
        lines.append(
            "IF NOT EXISTS (SELECT 1 FROM dbo.[User] WHERE Login = {login}) "
            "INSERT INTO dbo.[User](RoleId, FullName, Login, PasswordHash) "
            "VALUES ((SELECT RoleId FROM dbo.Role WHERE Name = {role}), {full}, {login}, {pw});".format(
                role=nstr(u.role),
                full=nstr(u.full_name),
                login=nstr(u.login),
                pw=nstr(u.password),
            )
        )
    lines.append("")

    lines.append("SET IDENTITY_INSERT dbo.PickupPoint ON;")
    for i, pp in enumerate(pickup_points, start=1):
        lines.append(
            "INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES ({id}, {pc}, {city}, {st}, {house});".format(
                id=str(i),
                pc=nstr(pp.postal_code),
                city=nstr(pp.city),
                st=nstr(pp.street),
                house=nstr(pp.house),
            )
        )
    lines.append("SET IDENTITY_INSERT dbo.PickupPoint OFF;")
    lines.append("")

    for p in products:
        discount_percent = round(float(p.discount_fraction) * 100.0, 2)
        image_path = f"Images/Products/{p.photo_file}" if p.photo_file else None
        lines.append(
            "IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = {art}) "
            "INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) "
            "VALUES ({art}, {name}, {unit}, {price}, "
            "(SELECT SupplierId FROM dbo.Supplier WHERE Name = {sup}), "
            "(SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = {man}), "
            "(SELECT CategoryId FROM dbo.Category WHERE Name = {cat}), "
            "{disc}, {qty}, {desc}, {img});".format(
                art=nstr(p.article),
                name=nstr(p.name),
                unit=nstr(p.unit),
                price=sql_decimal(p.price_rub),
                sup=nstr(p.supplier),
                man=nstr(p.manufacturer),
                cat=nstr(p.category),
                disc=str(discount_percent),
                qty=str(int(p.stock_qty)),
                desc=nstr(p.description),
                img=nstr(image_path) if image_path else "NULL",
            )
        )
    lines.append("")

    for o in orders:
        lines.append(
            "IF NOT EXISTS (SELECT 1 FROM dbo.[Order] WHERE OrderNumber = {num}) "
            "INSERT INTO dbo.[Order](OrderNumber, CustomerId, PickupPointId, OrderStatusId, OrderDate, DeliveryDate, ReceiveCode) "
            "VALUES ({num}, "
            "(SELECT TOP 1 UserId FROM dbo.[User] WHERE FullName = {full}), "
            "{ppid}, "
            "(SELECT OrderStatusId FROM dbo.OrderStatus WHERE Name = {st}), "
            "{od}, {dd}, {code});".format(
                num=str(o.order_number),
                full=nstr(o.customer_full_name),
                ppid=str(o.pickup_point_ref),
                st=nstr(o.status),
                od=sql_date(o.order_date),
                dd=sql_date(o.delivery_date),
                code=str(o.receive_code),
            )
        )
        for art, qty in parse_items(o.items_raw):
            lines.append(
                "INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) "
                "SELECT o.OrderId, p.ProductId, {qty} "
                "FROM dbo.[Order] o "
                "JOIN dbo.Product p ON p.Article = {art} "
                "WHERE o.OrderNumber = {num} "
                "AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);".format(
                    qty=str(qty),
                    art=nstr(art),
                    num=str(o.order_number),
                )
            )
        lines.append("")

    lines.append("COMMIT;\n")
    # Write with BOM to make Windows tooling reliably detect UTF-8.
    path.write_text("\n".join(lines), encoding="utf-8-sig")


def main() -> None:
    DB_DIR.mkdir(exist_ok=True)
    write_create_sql(DB_DIR / "01_create.sql")
    write_seed_sql(DB_DIR / "02_seed.sql")
    print("generated:", (DB_DIR / "01_create.sql").relative_to(ROOT))
    print("generated:", (DB_DIR / "02_seed.sql").relative_to(ROOT))


if __name__ == "__main__":
    main()

