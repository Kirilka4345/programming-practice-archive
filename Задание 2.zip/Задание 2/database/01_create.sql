﻿/* Auto-generated. DB: Posudarushka */

SET NOCOUNT ON;

IF DB_ID(N'Posudarushka') IS NULL
BEGIN
  CREATE DATABASE [Posudarushka] COLLATE Cyrillic_General_100_CI_AS_SC;
END
GO

USE [Posudarushka];
GO

IF OBJECT_ID(N'dbo.Role', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Role (
    RoleId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Role PRIMARY KEY,
    Name NVARCHAR(50) NOT NULL CONSTRAINT UQ_Role_Name UNIQUE
  );
END
GO

IF OBJECT_ID(N'dbo.[User]', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.[User] (
    UserId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_User PRIMARY KEY,
    RoleId INT NOT NULL CONSTRAINT FK_User_Role REFERENCES dbo.Role(RoleId),
    FullName NVARCHAR(200) NOT NULL,
    Login NVARCHAR(200) NOT NULL CONSTRAINT UQ_User_Login UNIQUE,
    PasswordHash NVARCHAR(200) NOT NULL
  );
END
GO

IF OBJECT_ID(N'dbo.Supplier', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Supplier (
    SupplierId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Supplier PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL CONSTRAINT UQ_Supplier_Name UNIQUE
  );
END
GO

IF OBJECT_ID(N'dbo.Manufacturer', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Manufacturer (
    ManufacturerId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Manufacturer PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL CONSTRAINT UQ_Manufacturer_Name UNIQUE
  );
END
GO

IF OBJECT_ID(N'dbo.Category', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Category (
    CategoryId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Category PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL CONSTRAINT UQ_Category_Name UNIQUE
  );
END
GO

IF OBJECT_ID(N'dbo.Product', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Product (
    ProductId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Product PRIMARY KEY,
    Article NVARCHAR(50) NOT NULL CONSTRAINT UQ_Product_Article UNIQUE,
    Name NVARCHAR(300) NOT NULL,
    Unit NVARCHAR(50) NOT NULL,
    PriceRub DECIMAL(18,2) NOT NULL CONSTRAINT CK_Product_Price CHECK (PriceRub >= 0),
    SupplierId INT NOT NULL CONSTRAINT FK_Product_Supplier REFERENCES dbo.Supplier(SupplierId),
    ManufacturerId INT NOT NULL CONSTRAINT FK_Product_Manufacturer REFERENCES dbo.Manufacturer(ManufacturerId),
    CategoryId INT NOT NULL CONSTRAINT FK_Product_Category REFERENCES dbo.Category(CategoryId),
    DiscountPercent DECIMAL(5,2) NOT NULL CONSTRAINT CK_Product_Discount CHECK (DiscountPercent >= 0 AND DiscountPercent <= 99.99),
    StockQty INT NOT NULL CONSTRAINT CK_Product_Stock CHECK (StockQty >= 0),
    Description NVARCHAR(MAX) NULL,
    ImagePath NVARCHAR(400) NULL
  );
END
GO

IF OBJECT_ID(N'dbo.PickupPoint', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.PickupPoint (
    PickupPointId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_PickupPoint PRIMARY KEY,
    PostalCode NVARCHAR(20) NOT NULL,
    City NVARCHAR(100) NOT NULL,
    Street NVARCHAR(200) NOT NULL,
    House NVARCHAR(50) NOT NULL,
    FullAddress AS (LTRIM(RTRIM(CONCAT(PostalCode, N', ', City, N', ', Street, N', ', House))))
  );
END
GO

IF OBJECT_ID(N'dbo.OrderStatus', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.OrderStatus (
    OrderStatusId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_OrderStatus PRIMARY KEY,
    Name NVARCHAR(50) NOT NULL CONSTRAINT UQ_OrderStatus_Name UNIQUE
  );
END
GO

IF OBJECT_ID(N'dbo.[Order]', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.[Order] (
    OrderId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Order PRIMARY KEY,
    OrderNumber INT NOT NULL CONSTRAINT UQ_Order_OrderNumber UNIQUE,
    CustomerId INT NOT NULL CONSTRAINT FK_Order_User REFERENCES dbo.[User](UserId),
    PickupPointId INT NOT NULL CONSTRAINT FK_Order_PickupPoint REFERENCES dbo.PickupPoint(PickupPointId),
    OrderStatusId INT NOT NULL CONSTRAINT FK_Order_Status REFERENCES dbo.OrderStatus(OrderStatusId),
    OrderDate DATE NOT NULL,
    DeliveryDate DATE NOT NULL,
    ReceiveCode INT NOT NULL,
    CONSTRAINT CK_Order_Dates CHECK (DeliveryDate >= OrderDate)
  );
END
GO

IF OBJECT_ID(N'dbo.OrderItem', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.OrderItem (
    OrderItemId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_OrderItem PRIMARY KEY,
    OrderId INT NOT NULL CONSTRAINT FK_OrderItem_Order REFERENCES dbo.[Order](OrderId) ON DELETE CASCADE,
    ProductId INT NOT NULL CONSTRAINT FK_OrderItem_Product REFERENCES dbo.Product(ProductId),
    Quantity INT NOT NULL CONSTRAINT CK_OrderItem_Qty CHECK (Quantity > 0),
    CONSTRAINT UQ_OrderItem_Order_Product UNIQUE (OrderId, ProductId)
  );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Product_Name' AND object_id = OBJECT_ID(N'dbo.Product'))
  CREATE INDEX IX_Product_Name ON dbo.Product(Name);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Order_OrderDate' AND object_id = OBJECT_ID(N'dbo.[Order]'))
  CREATE INDEX IX_Order_OrderDate ON dbo.[Order](OrderDate);
GO
