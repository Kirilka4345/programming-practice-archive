﻿/* Auto-generated. DB: Posudarushka */

SET NOCOUNT ON;

IF DB_ID(N'Posudarushka') IS NULL
BEGIN
  CREATE DATABASE [Posudarushka] COLLATE Cyrillic_General_100_CI_AS_SC;
END
GO

USE [Posudarushka];
GO

IF OBJECT_ID(N'dbo.Role', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Role (
    RoleId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Role PRIMARY KEY,
    Name NVARCHAR(50) NOT NULL CONSTRAINT UQ_Role_Name UNIQUE
  );
END
GO

IF OBJECT_ID(N'dbo.[User]', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.[User] (
    UserId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_User PRIMARY KEY,
    RoleId INT NOT NULL CONSTRAINT FK_User_Role REFERENCES dbo.Role(RoleId),
    FullName NVARCHAR(200) NOT NULL,
    Login NVARCHAR(200) NOT NULL CONSTRAINT UQ_User_Login UNIQUE,
    PasswordHash NVARCHAR(200) NOT NULL
  );
END
GO

IF OBJECT_ID(N'dbo.Supplier', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Supplier (
    SupplierId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Supplier PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL CONSTRAINT UQ_Supplier_Name UNIQUE
  );
END
GO

IF OBJECT_ID(N'dbo.Manufacturer', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Manufacturer (
    ManufacturerId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Manufacturer PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL CONSTRAINT UQ_Manufacturer_Name UNIQUE
  );
END
GO

IF OBJECT_ID(N'dbo.Category', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Category (
    CategoryId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Category PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL CONSTRAINT UQ_Category_Name UNIQUE
  );
END
GO

IF OBJECT_ID(N'dbo.Product', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Product (
    ProductId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Product PRIMARY KEY,
    Article NVARCHAR(50) NOT NULL CONSTRAINT UQ_Product_Article UNIQUE,
    Name NVARCHAR(300) NOT NULL,
    Unit NVARCHAR(50) NOT NULL,
    PriceRub DECIMAL(18,2) NOT NULL CONSTRAINT CK_Product_Price CHECK (PriceRub >= 0),
    SupplierId INT NOT NULL CONSTRAINT FK_Product_Supplier REFERENCES dbo.Supplier(SupplierId),
    ManufacturerId INT NOT NULL CONSTRAINT FK_Product_Manufacturer REFERENCES dbo.Manufacturer(ManufacturerId),
    CategoryId INT NOT NULL CONSTRAINT FK_Product_Category REFERENCES dbo.Category(CategoryId),
    DiscountPercent DECIMAL(5,2) NOT NULL CONSTRAINT CK_Product_Discount CHECK (DiscountPercent >= 0 AND DiscountPercent <= 99.99),
    StockQty INT NOT NULL CONSTRAINT CK_Product_Stock CHECK (StockQty >= 0),
    Description NVARCHAR(MAX) NULL,
    ImagePath NVARCHAR(400) NULL
  );
END
GO

IF OBJECT_ID(N'dbo.PickupPoint', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.PickupPoint (
    PickupPointId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_PickupPoint PRIMARY KEY,
    PostalCode NVARCHAR(20) NOT NULL,
    City NVARCHAR(100) NOT NULL,
    Street NVARCHAR(200) NOT NULL,
    House NVARCHAR(50) NOT NULL,
    FullAddress AS (LTRIM(RTRIM(CONCAT(PostalCode, N', ', City, N', ', Street, N', ', House))))
  );
END
GO

IF OBJECT_ID(N'dbo.OrderStatus', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.OrderStatus (
    OrderStatusId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_OrderStatus PRIMARY KEY,
    Name NVARCHAR(50) NOT NULL CONSTRAINT UQ_OrderStatus_Name UNIQUE
  );
END
GO

IF OBJECT_ID(N'dbo.[Order]', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.[Order] (
    OrderId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Order PRIMARY KEY,
    OrderNumber INT NOT NULL CONSTRAINT UQ_Order_OrderNumber UNIQUE,
    CustomerId INT NOT NULL CONSTRAINT FK_Order_User REFERENCES dbo.[User](UserId),
    PickupPointId INT NOT NULL CONSTRAINT FK_Order_PickupPoint REFERENCES dbo.PickupPoint(PickupPointId),
    OrderStatusId INT NOT NULL CONSTRAINT FK_Order_Status REFERENCES dbo.OrderStatus(OrderStatusId),
    OrderDate DATE NOT NULL,
    DeliveryDate DATE NOT NULL,
    ReceiveCode INT NOT NULL,
    CONSTRAINT CK_Order_Dates CHECK (DeliveryDate >= OrderDate)
  );
END
GO

IF OBJECT_ID(N'dbo.OrderItem', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.OrderItem (
    OrderItemId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_OrderItem PRIMARY KEY,
    OrderId INT NOT NULL CONSTRAINT FK_OrderItem_Order REFERENCES dbo.[Order](OrderId) ON DELETE CASCADE,
    ProductId INT NOT NULL CONSTRAINT FK_OrderItem_Product REFERENCES dbo.Product(ProductId),
    Quantity INT NOT NULL CONSTRAINT CK_OrderItem_Qty CHECK (Quantity > 0),
    CONSTRAINT UQ_OrderItem_Order_Product UNIQUE (OrderId, ProductId)
  );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Product_Name' AND object_id = OBJECT_ID(N'dbo.Product'))
  CREATE INDEX IX_Product_Name ON dbo.Product(Name);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Order_OrderDate' AND object_id = OBJECT_ID(N'dbo.[Order]'))
  CREATE INDEX IX_Order_OrderDate ON dbo.[Order](OrderDate);
GO

GO

/* Auto-generated seed for Posudarushka. */
SET NOCOUNT ON;
SET XACT_ABORT ON;
USE [Posudarushka];

BEGIN TRAN;

-- Clean existing data (safe for учебный проект)
DELETE FROM dbo.OrderItem;
DELETE FROM dbo.[Order];
DELETE FROM dbo.Product;
DELETE FROM dbo.PickupPoint;
DELETE FROM dbo.[User];
DELETE FROM dbo.OrderStatus;
DELETE FROM dbo.Category;
DELETE FROM dbo.Manufacturer;
DELETE FROM dbo.Supplier;
DELETE FROM dbo.Role;

DBCC CHECKIDENT('dbo.[User]', RESEED, 0);
DBCC CHECKIDENT('dbo.Supplier', RESEED, 0);
DBCC CHECKIDENT('dbo.Manufacturer', RESEED, 0);
DBCC CHECKIDENT('dbo.Category', RESEED, 0);
DBCC CHECKIDENT('dbo.Product', RESEED, 0);
DBCC CHECKIDENT('dbo.PickupPoint', RESEED, 0);
DBCC CHECKIDENT('dbo.OrderStatus', RESEED, 0);
DBCC CHECKIDENT('dbo.[Order]', RESEED, 0);
DBCC CHECKIDENT('dbo.OrderItem', RESEED, 0);

IF NOT EXISTS (SELECT 1 FROM dbo.Role WHERE Name = N'Администратор') INSERT INTO dbo.Role(Name) VALUES (N'Администратор');
IF NOT EXISTS (SELECT 1 FROM dbo.Role WHERE Name = N'Менеджер') INSERT INTO dbo.Role(Name) VALUES (N'Менеджер');
IF NOT EXISTS (SELECT 1 FROM dbo.Role WHERE Name = N'Клиент') INSERT INTO dbo.Role(Name) VALUES (N'Клиент');

IF NOT EXISTS (SELECT 1 FROM dbo.OrderStatus WHERE Name = N'Завершен') INSERT INTO dbo.OrderStatus(Name) VALUES (N'Завершен');
IF NOT EXISTS (SELECT 1 FROM dbo.OrderStatus WHERE Name = N'Новый') INSERT INTO dbo.OrderStatus(Name) VALUES (N'Новый');

IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = N'Магазин «Домашний уют»') INSERT INTO dbo.Supplier(Name) VALUES (N'Магазин «Домашний уют»');
IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = N'ООО «Посуда и декор»') INSERT INTO dbo.Supplier(Name) VALUES (N'ООО «Посуда и декор»');
IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = N'«Всё для кухни»') INSERT INTO dbo.Supplier(Name) VALUES (N'«Всё для кухни»');
IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = N'Магазин «Кухонная утварь»') INSERT INTO dbo.Supplier(Name) VALUES (N'Магазин «Кухонная утварь»');
IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = N'«Стеклянная посуда»') INSERT INTO dbo.Supplier(Name) VALUES (N'«Стеклянная посуда»');
IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = N'Магазин «Чайный дом»') INSERT INTO dbo.Supplier(Name) VALUES (N'Магазин «Чайный дом»');
IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = N'«Кухонная техника»') INSERT INTO dbo.Supplier(Name) VALUES (N'«Кухонная техника»');
IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = N'Магазин «Хозяюшка»') INSERT INTO dbo.Supplier(Name) VALUES (N'Магазин «Хозяюшка»');
IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = N'«Антикварный магазин»') INSERT INTO dbo.Supplier(Name) VALUES (N'«Антикварный магазин»');
IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = N'«Металлические изделия»') INSERT INTO dbo.Supplier(Name) VALUES (N'«Металлические изделия»');
IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = N'Магазин «Выпечка и десерты»') INSERT INTO dbo.Supplier(Name) VALUES (N'Магазин «Выпечка и десерты»');
IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = N'«Винный бутик»') INSERT INTO dbo.Supplier(Name) VALUES (N'«Винный бутик»');
IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = N'«Товары для кухни»') INSERT INTO dbo.Supplier(Name) VALUES (N'«Товары для кухни»');
IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = N'«Фарфоровая лавка»') INSERT INTO dbo.Supplier(Name) VALUES (N'«Фарфоровая лавка»');
IF NOT EXISTS (SELECT 1 FROM dbo.Supplier WHERE Name = N'Магазин «Кухонные принадлежности»') INSERT INTO dbo.Supplier(Name) VALUES (N'Магазин «Кухонные принадлежности»');

IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = N'«Керамика-Арт»') INSERT INTO dbo.Manufacturer(Name) VALUES (N'«Керамика-Арт»');
IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = N'«Фарфоровая мануфактура»') INSERT INTO dbo.Manufacturer(Name) VALUES (N'«Фарфоровая мануфактура»');
IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = N'«Металлические изделия»') INSERT INTO dbo.Manufacturer(Name) VALUES (N'«Металлические изделия»');
IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = N'«AlumCook»') INSERT INTO dbo.Manufacturer(Name) VALUES (N'«AlumCook»');
IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = N'«CrystalGlass»') INSERT INTO dbo.Manufacturer(Name) VALUES (N'«CrystalGlass»');
IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = N'«Чайная фабрика»') INSERT INTO dbo.Manufacturer(Name) VALUES (N'«Чайная фабрика»');
IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = N'«CookMaster»') INSERT INTO dbo.Manufacturer(Name) VALUES (N'«CookMaster»');
IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = N'«PlasticWare»') INSERT INTO dbo.Manufacturer(Name) VALUES (N'«PlasticWare»');
IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = N'«RoyalPorcelain»') INSERT INTO dbo.Manufacturer(Name) VALUES (N'«RoyalPorcelain»');
IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = N'«SteelCutlery»') INSERT INTO dbo.Manufacturer(Name) VALUES (N'«SteelCutlery»');
IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = N'«BakeWare»') INSERT INTO dbo.Manufacturer(Name) VALUES (N'«BakeWare»');
IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = N'«GlassArt»') INSERT INTO dbo.Manufacturer(Name) VALUES (N'«GlassArt»');
IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = N'«FoodStorage»') INSERT INTO dbo.Manufacturer(Name) VALUES (N'«FoodStorage»');
IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = N'«ElitePorcelain»') INSERT INTO dbo.Manufacturer(Name) VALUES (N'«ElitePorcelain»');
IF NOT EXISTS (SELECT 1 FROM dbo.Manufacturer WHERE Name = N'«WoodCraft»') INSERT INTO dbo.Manufacturer(Name) VALUES (N'«WoodCraft»');

IF NOT EXISTS (SELECT 1 FROM dbo.Category WHERE Name = N'Керамическая посуда') INSERT INTO dbo.Category(Name) VALUES (N'Керамическая посуда');
IF NOT EXISTS (SELECT 1 FROM dbo.Category WHERE Name = N'Фарфоровая посуда') INSERT INTO dbo.Category(Name) VALUES (N'Фарфоровая посуда');
IF NOT EXISTS (SELECT 1 FROM dbo.Category WHERE Name = N'Столовые приборы') INSERT INTO dbo.Category(Name) VALUES (N'Столовые приборы');
IF NOT EXISTS (SELECT 1 FROM dbo.Category WHERE Name = N'Кухонная посуда') INSERT INTO dbo.Category(Name) VALUES (N'Кухонная посуда');
IF NOT EXISTS (SELECT 1 FROM dbo.Category WHERE Name = N'Стеклянная посуда') INSERT INTO dbo.Category(Name) VALUES (N'Стеклянная посуда');
IF NOT EXISTS (SELECT 1 FROM dbo.Category WHERE Name = N'Антипригарная посуда') INSERT INTO dbo.Category(Name) VALUES (N'Антипригарная посуда');
IF NOT EXISTS (SELECT 1 FROM dbo.Category WHERE Name = N'Пластиковая посуда') INSERT INTO dbo.Category(Name) VALUES (N'Пластиковая посуда');
IF NOT EXISTS (SELECT 1 FROM dbo.Category WHERE Name = N'Деревянная посуда') INSERT INTO dbo.Category(Name) VALUES (N'Деревянная посуда');

IF NOT EXISTS (SELECT 1 FROM dbo.[User] WHERE Login = N'94d5ous@gmail.com') INSERT INTO dbo.[User](RoleId, FullName, Login, PasswordHash) VALUES ((SELECT RoleId FROM dbo.Role WHERE Name = N'Администратор'), N'Никифорова Весения Николаевна', N'94d5ous@gmail.com', N'uzWC67');
IF NOT EXISTS (SELECT 1 FROM dbo.[User] WHERE Login = N'uth4iz@mail.com') INSERT INTO dbo.[User](RoleId, FullName, Login, PasswordHash) VALUES ((SELECT RoleId FROM dbo.Role WHERE Name = N'Администратор'), N'Сазонов Руслан Германович', N'uth4iz@mail.com', N'2L6KZG');
IF NOT EXISTS (SELECT 1 FROM dbo.[User] WHERE Login = N'yzls62@outlook.com') INSERT INTO dbo.[User](RoleId, FullName, Login, PasswordHash) VALUES ((SELECT RoleId FROM dbo.Role WHERE Name = N'Администратор'), N'Одинцов Серафим Артёмович', N'yzls62@outlook.com', N'JlFRCZ');
IF NOT EXISTS (SELECT 1 FROM dbo.[User] WHERE Login = N'1diph5e@tutanota.com') INSERT INTO dbo.[User](RoleId, FullName, Login, PasswordHash) VALUES ((SELECT RoleId FROM dbo.Role WHERE Name = N'Менеджер'), N'Степанов Михаил Артёмович', N'1diph5e@tutanota.com', N'8ntwUp');
IF NOT EXISTS (SELECT 1 FROM dbo.[User] WHERE Login = N'tjde7c@yahoo.com') INSERT INTO dbo.[User](RoleId, FullName, Login, PasswordHash) VALUES ((SELECT RoleId FROM dbo.Role WHERE Name = N'Менеджер'), N'Ворсин Петр Евгеньевич', N'tjde7c@yahoo.com', N'YOyhfR');
IF NOT EXISTS (SELECT 1 FROM dbo.[User] WHERE Login = N'wpmrc3do@tutanota.com') INSERT INTO dbo.[User](RoleId, FullName, Login, PasswordHash) VALUES ((SELECT RoleId FROM dbo.Role WHERE Name = N'Менеджер'), N'Старикова Елена Павловна', N'wpmrc3do@tutanota.com', N'RSbvHv');
IF NOT EXISTS (SELECT 1 FROM dbo.[User] WHERE Login = N'5d4zbu@tutanota.com') INSERT INTO dbo.[User](RoleId, FullName, Login, PasswordHash) VALUES ((SELECT RoleId FROM dbo.Role WHERE Name = N'Клиент'), N'Михайлюк Анна Вячеславовна', N'5d4zbu@tutanota.com', N'rwVDh9');
IF NOT EXISTS (SELECT 1 FROM dbo.[User] WHERE Login = N'ptec8ym@yahoo.com') INSERT INTO dbo.[User](RoleId, FullName, Login, PasswordHash) VALUES ((SELECT RoleId FROM dbo.Role WHERE Name = N'Клиент'), N'Ситдикова Елена Анатольевна', N'ptec8ym@yahoo.com', N'LdNyos');
IF NOT EXISTS (SELECT 1 FROM dbo.[User] WHERE Login = N'1qz4kw@mail.com') INSERT INTO dbo.[User](RoleId, FullName, Login, PasswordHash) VALUES ((SELECT RoleId FROM dbo.Role WHERE Name = N'Клиент'), N'Ворсин Петр Евгеньевич', N'1qz4kw@mail.com', N'gynQMT');
IF NOT EXISTS (SELECT 1 FROM dbo.[User] WHERE Login = N'4np6se@mail.com') INSERT INTO dbo.[User](RoleId, FullName, Login, PasswordHash) VALUES ((SELECT RoleId FROM dbo.Role WHERE Name = N'Клиент'), N'Старикова Елена Павловна', N'4np6se@mail.com', N'AtnDjr');

SET IDENTITY_INSERT dbo.PickupPoint ON;
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (1, N'420151', N'г. Пушкино', N'ул. Вишневая', N'32');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (2, N'125061', N'г. Пушкино', N'ул. Подгорная', N'8');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (3, N'630370', N'г. Пушкино', N'ул. Шоссейная', N'24');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (4, N'400562', N'г. Пушкино', N'ул. Зеленая', N'32');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (5, N'614510', N'г. Пушкино', N'ул. Маяковского', N'47');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (6, N'410542', N'г. Пушкино', N'ул. Светлая', N'46');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (7, N'620839', N'г. Пушкино', N'ул. Цветочная', N'8');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (8, N'443890', N'г. Пушкино', N'ул. Коммунистическая', N'1');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (9, N'603379', N'г. Пушкино', N'ул. Спортивная', N'46');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (10, N'603721', N'г. Пушкино', N'ул. Гоголя', N'41');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (11, N'410172', N'г. Пушкино', N'ул. Северная', N'13');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (12, N'614611', N'г. Пушкино', N'ул. Молодежная', N'50');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (13, N'454311', N'г.Пушкино', N'ул. Новая', N'19');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (14, N'660007', N'г.Пушкино', N'ул. Октябрьская', N'19');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (15, N'603036', N'г. Пушкино', N'ул. Садовая', N'4');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (16, N'394060', N'г.Пушкино', N'ул. Фрунзе', N'43');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (17, N'410661', N'г. Пушкино', N'ул. Школьная', N'50');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (18, N'625590', N'г. Пушкино', N'ул. Коммунистическая', N'20');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (19, N'625683', N'г. Пушкино', N'ул. 8 Марта', N'');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (20, N'450983', N'г.Пушкино', N'ул. Комсомольская', N'26');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (21, N'394782', N'г. Пушкино', N'ул. Чехова', N'3');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (22, N'603002', N'г. Пушкино', N'ул. Дзержинского', N'28');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (23, N'450558', N'г. Пушкино', N'ул. Набережная', N'30');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (24, N'344288', N'г. Пушкино', N'ул. Чехова', N'1');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (25, N'614164', N'г.Пушкино', N'ул. Степная', N'30');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (26, N'394242', N'г. Пушкино', N'ул. Коммунистическая', N'43');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (27, N'660540', N'г. Пушкино', N'ул. Солнечная', N'25');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (28, N'125837', N'г. Пушкино', N'ул. Шоссейная', N'40');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (29, N'125703', N'г. Пушкино', N'ул. Партизанская', N'49');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (30, N'625283', N'г. Пушкино', N'ул. Победы', N'46');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (31, N'614753', N'г. Пушкино', N'ул. Полевая', N'35');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (32, N'426030', N'г. Пушкино', N'ул. Маяковского', N'44');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (33, N'450375', N'г. Пушкино ул. Клубная', N'44', N'');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (34, N'625560', N'г. Пушкино', N'ул. Некрасова', N'12');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (35, N'630201', N'г. Пушкино', N'ул. Комсомольская', N'17');
INSERT INTO dbo.PickupPoint(PickupPointId, PostalCode, City, Street, House) VALUES (36, N'190949', N'г. Пушкино', N'ул. Мичурина', N'26');
SET IDENTITY_INSERT dbo.PickupPoint OFF;

IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = N'PS001') INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) VALUES (N'PS001', N'Кружка керамическая 300 мл', N'шт.', 350.0, (SELECT SupplierId FROM dbo.Supplier WHERE Name = N'Магазин «Домашний уют»'), (SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = N'«Керамика-Арт»'), (SELECT CategoryId FROM dbo.Category WHERE Name = N'Керамическая посуда'), 5.0, 50, N'Кружка с глянцевым покрытием, объём 300 мл, цвет — синий, рисунок — цветочный орнамент', N'Images/Products/1.jpg');
IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = N'PS002') INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) VALUES (N'PS002', N'Тарелка обеденная 26 см', N'шт.', 250.0, (SELECT SupplierId FROM dbo.Supplier WHERE Name = N'ООО «Посуда и декор»'), (SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = N'«Фарфоровая мануфактура»'), (SELECT CategoryId FROM dbo.Category WHERE Name = N'Фарфоровая посуда'), 3.0, 75, N'Тарелка из тонкого фарфора, диаметр 26 см, цвет — белый, с золотым ободком', N'Images/Products/2.jpg');
IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = N'PS003') INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) VALUES (N'PS003', N'Набор столовых приборов (4 персоны)', N'набор', 2500.0, (SELECT SupplierId FROM dbo.Supplier WHERE Name = N'«Всё для кухни»'), (SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = N'«Металлические изделия»'), (SELECT CategoryId FROM dbo.Category WHERE Name = N'Столовые приборы'), 10.0, 15, N'Набор из нержавеющей стали, включает вилки, ножи и ложки, полированная поверхность', N'Images/Products/3.jpg');
IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = N'PS004') INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) VALUES (N'PS004', N'Кастрюля алюминиевая 3 л', N'шт.', 1800.0, (SELECT SupplierId FROM dbo.Supplier WHERE Name = N'Магазин «Кухонная утварь»'), (SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = N'«AlumCook»'), (SELECT CategoryId FROM dbo.Category WHERE Name = N'Кухонная посуда'), 7.0, 20, N'Кастрюля с антипригарным покрытием, объём 3 л, крышка из закалённого стекла', N'Images/Products/4.jpg');
IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = N'PS005') INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) VALUES (N'PS005', N'Салатник стеклянный 1,5 л', N'шт.', 650.0, (SELECT SupplierId FROM dbo.Supplier WHERE Name = N'«Стеклянная посуда»'), (SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = N'«CrystalGlass»'), (SELECT CategoryId FROM dbo.Category WHERE Name = N'Стеклянная посуда'), 0.0, 35, N'Салатник из закалённого стекла, объём 1,5 л, цвет — прозрачный, с рельефным узором', N'Images/Products/5.jpg');
IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = N'PS006') INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) VALUES (N'PS006', N'Чайная пара (чашка + блюдце)', N'комплект', 450.0, (SELECT SupplierId FROM dbo.Supplier WHERE Name = N'Магазин «Чайный дом»'), (SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = N'«Чайная фабрика»'), (SELECT CategoryId FROM dbo.Category WHERE Name = N'Керамическая посуда'), 5.0, 40, N'Чашка объёмом 200 мл и блюдце, керамика, цвет — пастельный голубой, с цветочным рисунком', N'Images/Products/6.jpg');
IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = N'PS007') INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) VALUES (N'PS007', N'Сковорода с антипригарным покрытием 28 см', N'шт.', 1900.0, (SELECT SupplierId FROM dbo.Supplier WHERE Name = N'«Кухонная техника»'), (SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = N'«CookMaster»'), (SELECT CategoryId FROM dbo.Category WHERE Name = N'Антипригарная посуда'), 8.0, 12, N'Сковорода с керамическим антипригарным покрытием, диаметр 28 см, съёмная ручка', N'Images/Products/7.jpg');
IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = N'PS008') INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) VALUES (N'PS008', N'Миска пластиковая 1 л', N'шт.', 150.0, (SELECT SupplierId FROM dbo.Supplier WHERE Name = N'Магазин «Хозяюшка»'), (SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = N'«PlasticWare»'), (SELECT CategoryId FROM dbo.Category WHERE Name = N'Пластиковая посуда'), 3.0, 100, N'Миска из пищевого пластика, объём 1 л, цвет — салатовый, устойчива к царапинам', N'Images/Products/8.jpg');
IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = N'PS009') INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) VALUES (N'PS009', N'Сервиз чайный на 6 персон', N'сервиз', 7500.0, (SELECT SupplierId FROM dbo.Supplier WHERE Name = N'«Антикварный магазин»'), (SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = N'«RoyalPorcelain»'), (SELECT CategoryId FROM dbo.Category WHERE Name = N'Фарфоровая посуда'), 10.0, 5, N'Сервиз из тонкого фарфора, включает чайник, сахарницу, молочник и 6 чашек с блюдцами, классический дизайн', N'Images/Products/9.jpg');
IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = N'PS010') INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) VALUES (N'PS010', N'Ложки столовые из нержавеющей стали (12 шт.)', N'упаковка', 800.0, (SELECT SupplierId FROM dbo.Supplier WHERE Name = N'«Металлические изделия»'), (SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = N'«SteelCutlery»'), (SELECT CategoryId FROM dbo.Category WHERE Name = N'Столовые приборы'), 0.0, 30, N'Ложки из нержавеющей стали, длина 20 см, полированная поверхность, упакованы в подарочную коробку', N'Images/Products/10.jpg');
IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = N'PS011') INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) VALUES (N'PS011', N'Форма для выпечки керамическая', N'шт.', 750.0, (SELECT SupplierId FROM dbo.Supplier WHERE Name = N'Магазин «Выпечка и десерты»'), (SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = N'«BakeWare»'), (SELECT CategoryId FROM dbo.Category WHERE Name = N'Керамическая посуда'), 5.0, 25, N'Форма для выпечки диаметром 25 см, высота 5 см, цвет — терракотовый, подходит для духовки и микроволновки', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = N'PS012') INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) VALUES (N'PS012', N'Бокал для вина 400 мл', N'шт.', 550.0, (SELECT SupplierId FROM dbo.Supplier WHERE Name = N'«Винный бутик»'), (SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = N'«GlassArt»'), (SELECT CategoryId FROM dbo.Category WHERE Name = N'Стеклянная посуда'), 7.0, 60, N'Бокал из хрустального стекла, объём 400 мл, высота 20 см, классический дизайн, подходит для красного вина', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = N'PS013') INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) VALUES (N'PS013', N'Контейнеры для хранения пищи (набор 3 шт.)', N'набор', 950.0, (SELECT SupplierId FROM dbo.Supplier WHERE Name = N'«Товары для кухни»'), (SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = N'«FoodStorage»'), (SELECT CategoryId FROM dbo.Category WHERE Name = N'Пластиковая посуда'), 3.0, 45, N'Набор контейнеров объёмом 0,5 л, 1 л и 1,5 л, изготовлены из пищевого пластика, герметичные крышки', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = N'PS014') INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) VALUES (N'PS014', N'Супница фарфоровая 3 л', N'шт.', 3200.0, (SELECT SupplierId FROM dbo.Supplier WHERE Name = N'«Фарфоровая лавка»'), (SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = N'«ElitePorcelain»'), (SELECT CategoryId FROM dbo.Category WHERE Name = N'Фарфоровая посуда'), 10.0, 8, N'Супница из тонкого фарфора, объём 3 л, цвет — белый с золотым орнаментом, с крышкой', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Article = N'PS015') INSERT INTO dbo.Product(Article, Name, Unit, PriceRub, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQty, Description, ImagePath) VALUES (N'PS015', N'Разделочные доски (набор 3 шт.)', N'набор', 1200.0, (SELECT SupplierId FROM dbo.Supplier WHERE Name = N'Магазин «Кухонные принадлежности»'), (SELECT ManufacturerId FROM dbo.Manufacturer WHERE Name = N'«WoodCraft»'), (SELECT CategoryId FROM dbo.Category WHERE Name = N'Деревянная посуда'), 0.0, 20, N'Набор досок из бамбука, размеры: 30×20 см, 25×15 см и 20×10 см, толщина 3 мм, с нескользящими ножками', NULL);

IF NOT EXISTS (SELECT 1 FROM dbo.[Order] WHERE OrderNumber = 1) INSERT INTO dbo.[Order](OrderNumber, CustomerId, PickupPointId, OrderStatusId, OrderDate, DeliveryDate, ReceiveCode) VALUES (1, (SELECT TOP 1 UserId FROM dbo.[User] WHERE FullName = N'Степанов Михаил Артёмович'), 1, (SELECT OrderStatusId FROM dbo.OrderStatus WHERE Name = N'Завершен'), '2025-02-27', '2025-04-20', 901);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 2 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS001' WHERE o.OrderNumber = 1 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 2 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS005' WHERE o.OrderNumber = 1 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);

IF NOT EXISTS (SELECT 1 FROM dbo.[Order] WHERE OrderNumber = 2) INSERT INTO dbo.[Order](OrderNumber, CustomerId, PickupPointId, OrderStatusId, OrderDate, DeliveryDate, ReceiveCode) VALUES (2, (SELECT TOP 1 UserId FROM dbo.[User] WHERE FullName = N'Никифорова Весения Николаевна'), 11, (SELECT OrderStatusId FROM dbo.OrderStatus WHERE Name = N'Завершен'), '2022-09-28', '2025-04-21', 902);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 1 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS015' WHERE o.OrderNumber = 2 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 2 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS010' WHERE o.OrderNumber = 2 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);

IF NOT EXISTS (SELECT 1 FROM dbo.[Order] WHERE OrderNumber = 3) INSERT INTO dbo.[Order](OrderNumber, CustomerId, PickupPointId, OrderStatusId, OrderDate, DeliveryDate, ReceiveCode) VALUES (3, (SELECT TOP 1 UserId FROM dbo.[User] WHERE FullName = N'Сазонов Руслан Германович'), 2, (SELECT OrderStatusId FROM dbo.OrderStatus WHERE Name = N'Завершен'), '2025-03-21', '2025-04-22', 903);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 4 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS002' WHERE o.OrderNumber = 3 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 5 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS004' WHERE o.OrderNumber = 3 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);

IF NOT EXISTS (SELECT 1 FROM dbo.[Order] WHERE OrderNumber = 4) INSERT INTO dbo.[Order](OrderNumber, CustomerId, PickupPointId, OrderStatusId, OrderDate, DeliveryDate, ReceiveCode) VALUES (4, (SELECT TOP 1 UserId FROM dbo.[User] WHERE FullName = N'Одинцов Серафим Артёмович'), 11, (SELECT OrderStatusId FROM dbo.OrderStatus WHERE Name = N'Завершен'), '2025-02-20', '2025-04-23', 904);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 1 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS003' WHERE o.OrderNumber = 4 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 3 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS012' WHERE o.OrderNumber = 4 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);

IF NOT EXISTS (SELECT 1 FROM dbo.[Order] WHERE OrderNumber = 5) INSERT INTO dbo.[Order](OrderNumber, CustomerId, PickupPointId, OrderStatusId, OrderDate, DeliveryDate, ReceiveCode) VALUES (5, (SELECT TOP 1 UserId FROM dbo.[User] WHERE FullName = N'Степанов Михаил Артёмович'), 2, (SELECT OrderStatusId FROM dbo.OrderStatus WHERE Name = N'Завершен'), '2025-03-17', '2025-04-24', 905);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 2 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS001' WHERE o.OrderNumber = 5 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 2 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS009' WHERE o.OrderNumber = 5 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);

IF NOT EXISTS (SELECT 1 FROM dbo.[Order] WHERE OrderNumber = 6) INSERT INTO dbo.[Order](OrderNumber, CustomerId, PickupPointId, OrderStatusId, OrderDate, DeliveryDate, ReceiveCode) VALUES (6, (SELECT TOP 1 UserId FROM dbo.[User] WHERE FullName = N'Никифорова Весения Николаевна'), 15, (SELECT OrderStatusId FROM dbo.OrderStatus WHERE Name = N'Завершен'), '2025-03-01', '2025-04-25', 906);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 5 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS014' WHERE o.OrderNumber = 6 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 4 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS013' WHERE o.OrderNumber = 6 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);

IF NOT EXISTS (SELECT 1 FROM dbo.[Order] WHERE OrderNumber = 7) INSERT INTO dbo.[Order](OrderNumber, CustomerId, PickupPointId, OrderStatusId, OrderDate, DeliveryDate, ReceiveCode) VALUES (7, (SELECT TOP 1 UserId FROM dbo.[User] WHERE FullName = N'Сазонов Руслан Германович'), 3, (SELECT OrderStatusId FROM dbo.OrderStatus WHERE Name = N'Завершен'), '2025-02-28', '2025-04-26', 907);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 1 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS015' WHERE o.OrderNumber = 7 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 2 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS010' WHERE o.OrderNumber = 7 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);

IF NOT EXISTS (SELECT 1 FROM dbo.[Order] WHERE OrderNumber = 8) INSERT INTO dbo.[Order](OrderNumber, CustomerId, PickupPointId, OrderStatusId, OrderDate, DeliveryDate, ReceiveCode) VALUES (8, (SELECT TOP 1 UserId FROM dbo.[User] WHERE FullName = N'Одинцов Серафим Артёмович'), 19, (SELECT OrderStatusId FROM dbo.OrderStatus WHERE Name = N'Новый'), '2025-03-31', '2025-04-27', 908);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 1 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS011' WHERE o.OrderNumber = 8 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 7 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS006' WHERE o.OrderNumber = 8 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);

IF NOT EXISTS (SELECT 1 FROM dbo.[Order] WHERE OrderNumber = 9) INSERT INTO dbo.[Order](OrderNumber, CustomerId, PickupPointId, OrderStatusId, OrderDate, DeliveryDate, ReceiveCode) VALUES (9, (SELECT TOP 1 UserId FROM dbo.[User] WHERE FullName = N'Степанов Михаил Артёмович'), 5, (SELECT OrderStatusId FROM dbo.OrderStatus WHERE Name = N'Новый'), '2025-04-02', '2025-04-28', 909);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 10 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS009' WHERE o.OrderNumber = 9 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 2 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS010' WHERE o.OrderNumber = 9 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);

IF NOT EXISTS (SELECT 1 FROM dbo.[Order] WHERE OrderNumber = 10) INSERT INTO dbo.[Order](OrderNumber, CustomerId, PickupPointId, OrderStatusId, OrderDate, DeliveryDate, ReceiveCode) VALUES (10, (SELECT TOP 1 UserId FROM dbo.[User] WHERE FullName = N'Степанов Михаил Артёмович'), 19, (SELECT OrderStatusId FROM dbo.OrderStatus WHERE Name = N'Новый'), '2025-04-03', '2025-04-29', 910);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 3 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS015' WHERE o.OrderNumber = 10 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);
INSERT INTO dbo.OrderItem(OrderId, ProductId, Quantity) SELECT o.OrderId, p.ProductId, 3 FROM dbo.[Order] o JOIN dbo.Product p ON p.Article = N'PS007' WHERE o.OrderNumber = 10 AND NOT EXISTS (SELECT 1 FROM dbo.OrderItem oi WHERE oi.OrderId = o.OrderId AND oi.ProductId = p.ProductId);

COMMIT;
