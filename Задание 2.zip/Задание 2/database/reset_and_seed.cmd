@echo off
setlocal

REM Force UTF-8 codepage for console output.
chcp 65001 >nul

REM Usage: reset_and_seed.cmd [server]
REM Example: reset_and_seed.cmd localhost\SQLEXPRESS

set "SERVER=%~1"
if "%SERVER%"=="" set "SERVER=localhost"

echo Using SQL Server: %SERVER%
echo Creating database...
sqlcmd -S "%SERVER%" -E -C -f 65001 -i "%~dp0\01_create.sql"
if errorlevel 1 goto :fail

echo Seeding database...
sqlcmd -S "%SERVER%" -E -C -d Posudarushka -f 65001 -i "%~dp0\02_seed.sql"
if errorlevel 1 goto :fail

echo Done.
exit /b 0

:fail
echo.
echo ERROR: sqlcmd failed. Check that SQL Server is running and you have access.
exit /b 1

