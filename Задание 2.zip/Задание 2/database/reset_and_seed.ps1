$ErrorActionPreference = "Stop"

param(
  [string]$Server = "localhost"
)

Write-Host "Using SQL Server: $Server"

$root = Split-Path -Parent $PSCommandPath

# Ensure UTF-8 for sqlcmd input decoding.
$common = @("-S", $Server, "-E", "-C", "-f", "65001")

Write-Host "Creating database..."
sqlcmd @common -i (Join-Path $root "01_create.sql")

Write-Host "Seeding database..."
sqlcmd @common -d "Posudarushka" -i (Join-Path $root "02_seed.sql")

Write-Host "Done."

