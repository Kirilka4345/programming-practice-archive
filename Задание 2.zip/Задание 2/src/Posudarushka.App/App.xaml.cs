﻿using System.Windows;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Posudarushka.App.Data;
using Posudarushka.App.Services;
using Posudarushka.App.Views;

namespace Posudarushka.App;

public partial class App : Application
{
    private IHost? _host;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        _host = Host.CreateDefaultBuilder()
            .ConfigureAppConfiguration(cfg =>
            {
                cfg.SetBasePath(AppContext.BaseDirectory);
                cfg.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
            })
            .ConfigureServices((ctx, services) =>
            {
                var cs = ctx.Configuration.GetConnectionString("Default")
                         ?? throw new InvalidOperationException("Missing ConnectionStrings:Default in appsettings.json");

                services.AddDbContext<PosudarushkaDbContext>(o => o.UseSqlServer(cs));

                services.AddSingleton<CurrentSession>();
                services.AddSingleton<AppMessageBox>();
            })
            .Build();

        try
        {
            // Fast connectivity check: if DB isn't created yet, show a friendly instruction.
            using var scope = _host.Services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<PosudarushkaDbContext>();
            db.Database.OpenConnection();
            db.Database.CloseConnection();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Не удалось подключиться к базе данных.\n\n" +
                "Скорее всего, база ещё не создана/не заполнена.\n" +
                "Запусти скрипты из папки database (01_create.sql, затем 02_seed.sql),\n" +
                "или проверь строку подключения в appsettings.json.\n\n" +
                $"Технические детали:\n{ex.Message}",
                "Ошибка подключения к БД",
                MessageBoxButton.OK,
                MessageBoxImage.Error
            );
        }

        var login = new LoginWindow(_host.Services);
        MainWindow = login;
        login.Show();
    }

    protected override async void OnExit(ExitEventArgs e)
    {
        if (_host != null)
        {
            await _host.StopAsync(TimeSpan.FromSeconds(2));
            _host.Dispose();
        }
        base.OnExit(e);
    }
}

