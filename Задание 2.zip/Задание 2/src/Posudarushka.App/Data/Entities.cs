using System.ComponentModel.DataAnnotations;

namespace Posudarushka.App.Data;

public sealed class Role
{
    public int RoleId { get; set; }
    [MaxLength(50)]
    public required string Name { get; set; }
}

public sealed class User
{
    public int UserId { get; set; }
    public int RoleId { get; set; }
    public Role? Role { get; set; }

    [MaxLength(200)]
    public required string FullName { get; set; }

    [MaxLength(200)]
    public required string Login { get; set; }

    [MaxLength(200)]
    public required string PasswordHash { get; set; }
}

public sealed class Supplier
{
    public int SupplierId { get; set; }
    [MaxLength(200)]
    public required string Name { get; set; }
}

public sealed class Manufacturer
{
    public int ManufacturerId { get; set; }
    [MaxLength(200)]
    public required string Name { get; set; }
}

public sealed class Category
{
    public int CategoryId { get; set; }
    [MaxLength(200)]
    public required string Name { get; set; }
}

public sealed class Product
{
    public int ProductId { get; set; }

    [MaxLength(50)]
    public required string Article { get; set; }

    [MaxLength(300)]
    public required string Name { get; set; }

    [MaxLength(50)]
    public required string Unit { get; set; }

    public decimal PriceRub { get; set; }

    public int SupplierId { get; set; }
    public Supplier? Supplier { get; set; }

    public int ManufacturerId { get; set; }
    public Manufacturer? Manufacturer { get; set; }

    public int CategoryId { get; set; }
    public Category? Category { get; set; }

    /// <summary>Discount in percent, e.g. 5.00</summary>
    public decimal DiscountPercent { get; set; }

    public int StockQty { get; set; }
    public string? Description { get; set; }

    /// <summary>Relative path like Images/Products/1.jpg</summary>
    [MaxLength(400)]
    public string? ImagePath { get; set; }
}

public sealed class PickupPoint
{
    public int PickupPointId { get; set; }

    [MaxLength(20)]
    public required string PostalCode { get; set; }

    [MaxLength(100)]
    public required string City { get; set; }

    [MaxLength(200)]
    public required string Street { get; set; }

    [MaxLength(50)]
    public required string House { get; set; }

    public string? FullAddress { get; set; }
}

public sealed class OrderStatus
{
    public int OrderStatusId { get; set; }
    [MaxLength(50)]
    public required string Name { get; set; }
}

public sealed class Order
{
    public int OrderId { get; set; }
    public int OrderNumber { get; set; }

    public int CustomerId { get; set; }
    public User? Customer { get; set; }

    public int PickupPointId { get; set; }
    public PickupPoint? PickupPoint { get; set; }

    public int OrderStatusId { get; set; }
    public OrderStatus? OrderStatus { get; set; }

    public DateOnly OrderDate { get; set; }
    public DateOnly DeliveryDate { get; set; }
    public int ReceiveCode { get; set; }

    public List<OrderItem> Items { get; set; } = [];
}

public sealed class OrderItem
{
    public int OrderItemId { get; set; }
    public int OrderId { get; set; }
    public Order? Order { get; set; }

    public int ProductId { get; set; }
    public Product? Product { get; set; }

    public int Quantity { get; set; }
}

