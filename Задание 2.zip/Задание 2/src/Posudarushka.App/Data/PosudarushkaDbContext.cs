using Microsoft.EntityFrameworkCore;

namespace Posudarushka.App.Data;

public sealed class PosudarushkaDbContext(DbContextOptions<PosudarushkaDbContext> options) : DbContext(options)
{
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<User> Users => Set<User>();
    public DbSet<Supplier> Suppliers => Set<Supplier>();
    public DbSet<Manufacturer> Manufacturers => Set<Manufacturer>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<PickupPoint> PickupPoints => Set<PickupPoint>();
    public DbSet<OrderStatus> OrderStatuses => Set<OrderStatus>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Role>().ToTable("Role").HasIndex(x => x.Name).IsUnique();

        modelBuilder.Entity<User>().ToTable("User").HasIndex(x => x.Login).IsUnique();
        modelBuilder.Entity<User>()
            .HasOne(x => x.Role)
            .WithMany()
            .HasForeignKey(x => x.RoleId);

        modelBuilder.Entity<Supplier>().ToTable("Supplier").HasIndex(x => x.Name).IsUnique();
        modelBuilder.Entity<Manufacturer>().ToTable("Manufacturer").HasIndex(x => x.Name).IsUnique();
        modelBuilder.Entity<Category>().ToTable("Category").HasIndex(x => x.Name).IsUnique();

        modelBuilder.Entity<Product>().ToTable("Product").HasIndex(x => x.Article).IsUnique();
        modelBuilder.Entity<Product>()
            .HasOne(x => x.Supplier)
            .WithMany()
            .HasForeignKey(x => x.SupplierId);
        modelBuilder.Entity<Product>()
            .HasOne(x => x.Manufacturer)
            .WithMany()
            .HasForeignKey(x => x.ManufacturerId);
        modelBuilder.Entity<Product>()
            .HasOne(x => x.Category)
            .WithMany()
            .HasForeignKey(x => x.CategoryId);

        modelBuilder.Entity<PickupPoint>().ToTable("PickupPoint");
        modelBuilder.Entity<PickupPoint>()
            .Property(x => x.FullAddress)
            .HasComputedColumnSql("LTRIM(RTRIM(CONCAT(PostalCode, N', ', City, N', ', Street, N', ', House)))", stored: false);

        modelBuilder.Entity<OrderStatus>().ToTable("OrderStatus").HasIndex(x => x.Name).IsUnique();

        modelBuilder.Entity<Order>().ToTable("Order").HasIndex(x => x.OrderNumber).IsUnique();
        modelBuilder.Entity<Order>()
            .HasOne(x => x.Customer)
            .WithMany()
            .HasForeignKey(x => x.CustomerId)
            .OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Order>()
            .HasOne(x => x.PickupPoint)
            .WithMany()
            .HasForeignKey(x => x.PickupPointId)
            .OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Order>()
            .HasOne(x => x.OrderStatus)
            .WithMany()
            .HasForeignKey(x => x.OrderStatusId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<OrderItem>().ToTable("OrderItem");
        modelBuilder.Entity<OrderItem>()
            .HasIndex(x => new { x.OrderId, x.ProductId })
            .IsUnique();
        modelBuilder.Entity<OrderItem>()
            .HasOne(x => x.Order)
            .WithMany(x => x.Items)
            .HasForeignKey(x => x.OrderId)
            .OnDelete(DeleteBehavior.Cascade);
        modelBuilder.Entity<OrderItem>()
            .HasOne(x => x.Product)
            .WithMany()
            .HasForeignKey(x => x.ProductId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

