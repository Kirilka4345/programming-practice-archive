using System.Globalization;
using System.Windows.Data;

namespace Posudarushka.App;

/// <summary>
/// Returns true if numeric value is strictly greater than ConverterParameter.
/// </summary>
public sealed class GreaterThanConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is null || parameter is null)
            return false;

        if (!double.TryParse(value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out var v) &&
            !double.TryParse(value.ToString(), NumberStyles.Any, culture, out v))
            return false;

        if (!double.TryParse(parameter.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out var p) &&
            !double.TryParse(parameter.ToString(), NumberStyles.Any, culture, out p))
            return false;

        return v > p;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        Binding.DoNothing;
}

