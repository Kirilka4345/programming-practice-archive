using Posudarushka.App.Data;

namespace Posudarushka.App.Services;

public enum AppRole
{
    Guest,
    Client,
    Manager,
    Admin
}

public sealed class CurrentSession
{
    public User? User { get; private set; }
    public AppRole Role { get; private set; } = AppRole.Guest;

    public string DisplayName => User?.FullName ?? "Гость";

    public void SetGuest()
    {
        User = null;
        Role = AppRole.Guest;
    }

    public bool IsAdmin => Role == AppRole.Admin;
    public bool IsManager => Role == AppRole.Manager;
    public bool IsAdminOrManager => Role == AppRole.Admin || Role == AppRole.Manager;

    public void SetUser(User user)
    {
        User = user;
        Role = user.Role?.Name switch
        {
            "Администратор" => AppRole.Admin,
            "Менеджер" => AppRole.Manager,
            "Клиент" => AppRole.Client,
            _ => AppRole.Client
        };
    }
}

