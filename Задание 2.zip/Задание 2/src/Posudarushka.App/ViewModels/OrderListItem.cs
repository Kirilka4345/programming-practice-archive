using Posudarushka.App.Data;

namespace Posudarushka.App.ViewModels;

public sealed class OrderListItem
{
    private readonly Order _o;

    public OrderListItem(Order o)
    {
        _o = o;
    }

    public int OrderId => _o.OrderId;
    public int OrderNumber => _o.OrderNumber;
    public string Status => _o.OrderStatus?.Name ?? "";
    public string PickupPoint => _o.PickupPoint?.FullAddress ?? "";
    public string Customer => _o.Customer?.FullName ?? "";
    public DateOnly OrderDate => _o.OrderDate;
    public DateOnly DeliveryDate => _o.DeliveryDate;
    public int ReceiveCode => _o.ReceiveCode;

    public string ItemsSummary
    {
        get
        {
            if (_o.Items.Count == 0)
                return "";
            return string.Join(", ", _o.Items.Select(i => $"{i.Product?.Article ?? "?"} x{i.Quantity}"));
        }
    }
}

