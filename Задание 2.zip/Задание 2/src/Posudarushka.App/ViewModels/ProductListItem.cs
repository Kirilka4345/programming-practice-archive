using System.IO;
using Posudarushka.App.Data;

namespace Posudarushka.App.ViewModels;

public sealed class ProductListItem
{
    private readonly Product _p;

    public ProductListItem(Product p)
    {
        _p = p;
    }

    public int ProductId => _p.ProductId;
    public string Article => _p.Article;
    public string Name => _p.Name;
    public string Unit => _p.Unit;
    public decimal PriceRub => _p.PriceRub;
    public decimal DiscountPercent => _p.DiscountPercent;
    public int StockQty => _p.StockQty;
    public string? Description => _p.Description;

    public string Supplier => _p.Supplier?.Name ?? "";
    public string Manufacturer => _p.Manufacturer?.Name ?? "";
    public string Category => _p.Category?.Name ?? "";

    public bool HasDiscount => DiscountPercent > 0;
    public bool IsOutOfStock => StockQty <= 0;

    public decimal FinalPriceRub => HasDiscount
        ? Math.Round(PriceRub * (100m - DiscountPercent) / 100m, 2)
        : PriceRub;

    public string PriceText => $"{PriceRub:0.00} руб.";
    public string FinalPriceText => $"{FinalPriceRub:0.00} руб.";

    public string DiscountText => $"{DiscountPercent:0.##}%";

    public string StockText => $"{StockQty} {Unit}";

    public string ImagePathResolved
    {
        get
        {
            var baseDir = AppContext.BaseDirectory;
            var placeholder = Path.Combine(baseDir, "Assets", "picture.png");
            var rel = _p.ImagePath;
            if (string.IsNullOrWhiteSpace(rel))
                return placeholder;
            var full = Path.Combine(baseDir, rel.Replace('/', Path.DirectorySeparatorChar));
            return File.Exists(full) ? full : placeholder;
        }
    }
}

