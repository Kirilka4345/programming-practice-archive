using System.IO;
using System.Windows;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Posudarushka.App.Data;
using Posudarushka.App.Services;

namespace Posudarushka.App.Views;

public partial class LoginWindow : Window
{
    private readonly IServiceProvider _services;

    public string LogoPath { get; }

    private int _failedAttempts = 0;
    private string _currentCaptcha = "";

    public LoginWindow(IServiceProvider services)
    {
        _services = services;

        // Use pack URI for resource
        LogoPath = "pack://application:,,,/Assets/Logo.png";

        InitializeComponent();
        DataContext = this;
    }

    private void GenerateCaptcha()
    {
        const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        var rnd = new Random();
        _currentCaptcha = new string(Enumerable.Repeat(chars, 4).Select(s => s[rnd.Next(s.Length)]).ToArray());
        CaptchaText.Text = _currentCaptcha;
        CaptchaInput.Text = "";
        CaptchaPanel.Visibility = Visibility.Visible;
    }

    private void RefreshCaptcha_Click(object sender, RoutedEventArgs e)
    {
        GenerateCaptcha();
    }

    private async void Login_Click(object sender, RoutedEventArgs e)
    {
        // Check Captcha if visible
        if (CaptchaPanel.Visibility == Visibility.Visible)
        {
            if (!string.Equals(CaptchaInput.Text, _currentCaptcha, StringComparison.OrdinalIgnoreCase))
            {
                _services.GetRequiredService<AppMessageBox>().Error("Неверный код с картинки.");
                GenerateCaptcha();
                return;
            }
        }

        var login = LoginTextBox.Text.Trim();
        var pw = PasswordBox.Password;

        if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(pw))
        {
            _services.GetRequiredService<AppMessageBox>().Warn("Введите логин и пароль.");
            return;
        }

        try
        {
            using var scope = _services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<PosudarushkaDbContext>();
            var user = await db.Users
                .Include(u => u.Role)
                .FirstOrDefaultAsync(u => u.Login == login && u.PasswordHash == pw);

            if (user == null)
            {
                _failedAttempts++;
                if (_failedAttempts >= 1) // Show captcha after first failure
                {
                    GenerateCaptcha();
                    _services.GetRequiredService<AppMessageBox>().Error(
                        "Неверный логин или пароль.\nВведите код с картинки для продолжения.",
                        "Ошибка авторизации"
                    );
                }
                else
                {
                    _services.GetRequiredService<AppMessageBox>().Error(
                        "Неверный логин или пароль.\nПроверьте раскладку клавиатуры и повторите попытку.",
                        "Ошибка авторизации"
                    );
                }
                return;
            }

            var session = _services.GetRequiredService<CurrentSession>();
            session.SetUser(user);

            OpenShellAndClose();
        }
        catch (Exception ex)
        {
            _services.GetRequiredService<AppMessageBox>().Error(
                $"Не удалось выполнить вход.\n\n{ex.Message}",
                "Ошибка"
            );
        }
    }

    private void Guest_Click(object sender, RoutedEventArgs e)
    {
        _services.GetRequiredService<CurrentSession>().SetGuest();
        OpenShellAndClose();
    }

    private void OpenShellAndClose()
    {
        var shell = new ShellWindow(_services);
        Application.Current.MainWindow = shell;
        shell.Show();
        Close();
    }
}

