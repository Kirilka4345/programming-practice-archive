using System.Globalization;
using System.Windows;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Posudarushka.App.Data;
using Posudarushka.App.Services;

namespace Posudarushka.App.Views;

public partial class OrderEditWindow : Window
{
    private readonly IServiceProvider _services;
    private readonly AppMessageBox _msg;
    private readonly CurrentSession _session;
    private readonly int? _orderId;

    public string HeaderText => _orderId == null ? "Добавление заказа" : "Редактирование заказа";

    public OrderEditWindow(IServiceProvider services, int? orderId)
    {
        _services = services;
        _msg = services.GetRequiredService<AppMessageBox>();
        _session = services.GetRequiredService<CurrentSession>();
        _orderId = orderId;

        if (!_session.IsAdminOrManager)
            throw new InvalidOperationException("Only admin or manager can edit orders");

        InitializeComponent();
        DataContext = this;

        Loaded += OrderEditWindow_Loaded;
    }

    private async void OrderEditWindow_Loaded(object sender, RoutedEventArgs e)
    {
        try
        {
            using var scope = _services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<PosudarushkaDbContext>();

            var statuses = await db.OrderStatuses.AsNoTracking().OrderBy(x => x.Name).ToListAsync();
            var pickup = await db.PickupPoints.AsNoTracking().OrderBy(x => x.PickupPointId).ToListAsync();

            StatusCombo.ItemsSource = statuses;
            StatusCombo.DisplayMemberPath = "Name";
            PickupCombo.ItemsSource = pickup;

            if (_orderId == null)
            {
                // auto compute next number (max + 1)
                var maxNum = await db.Orders.MaxAsync(o => (int?)o.OrderNumber) ?? 0;
                OrderNumberTextBox.Text = (maxNum + 1).ToString(CultureInfo.InvariantCulture);

                StatusCombo.SelectedIndex = statuses.Count > 0 ? 0 : -1;
                PickupCombo.SelectedIndex = pickup.Count > 0 ? 0 : -1;
                OrderDatePicker.SelectedDate = DateTime.Today;
                DeliveryDatePicker.SelectedDate = DateTime.Today;
                ReceiveCodeTextBox.Text = "1000";
                ItemsRawTextBox.Text = "";
                return;
            }

            var order = await db.Orders
                .Include(o => o.OrderStatus)
                .Include(o => o.PickupPoint)
                .Include(o => o.Items).ThenInclude(i => i.Product)
                .FirstOrDefaultAsync(o => o.OrderId == _orderId.Value);
            if (order == null)
            {
                _msg.Error("Заказ не найден.");
                DialogResult = false;
                Close();
                return;
            }

            OrderNumberTextBox.Text = order.OrderNumber.ToString(CultureInfo.InvariantCulture);
            StatusCombo.SelectedItem = statuses.FirstOrDefault(s => s.OrderStatusId == order.OrderStatusId);
            PickupCombo.SelectedItem = pickup.FirstOrDefault(p => p.PickupPointId == order.PickupPointId);
            OrderDatePicker.SelectedDate = order.OrderDate.ToDateTime(TimeOnly.MinValue);
            DeliveryDatePicker.SelectedDate = order.DeliveryDate.ToDateTime(TimeOnly.MinValue);
            ReceiveCodeTextBox.Text = order.ReceiveCode.ToString(CultureInfo.InvariantCulture);

            ItemsRawTextBox.Text = string.Join(", ", order.Items.Select(i => $"{i.Product?.Article ?? "?"}, {i.Quantity}"));
        }
        catch (Exception ex)
        {
            _msg.Error($"Не удалось загрузить форму заказа.\n\n{ex.Message}");
        }
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
        Close();
    }

    private void CheckItems_Click(object sender, RoutedEventArgs e)
    {
        var raw = ItemsRawTextBox.Text.Trim();
        var parsed = ParseItemsRaw(raw);
        if (parsed.Count == 0)
        {
            _msg.Info("Список товаров пуст или имеет неверный формат.\nПример: PS001, 2, PS005, 1");
            return;
        }

        var lines = parsed.Select(p => $"Артикул: {p.Article}, Кол-во: {p.Qty}");
        _msg.Info("Распознанные товары:\n\n" + string.Join("\n", lines), "Проверка состава");
    }

    private static List<(string Article, int Qty)> ParseItemsRaw(string raw)
    {
        var parts = raw.Split(',').Select(p => p.Trim()).Where(p => !string.IsNullOrWhiteSpace(p)).ToList();
        var outList = new List<(string Article, int Qty)>();
        for (var i = 0; i + 1 < parts.Count; i += 2)
        {
            var art = parts[i];
            var qty = int.TryParse(parts[i + 1], out var q) && q > 0 ? q : 1;
            outList.Add((art, qty));
        }
        return outList;
    }

    private async void Save_Click(object sender, RoutedEventArgs e)
    {
        if (!int.TryParse(OrderNumberTextBox.Text.Trim(), out var orderNumber) || orderNumber <= 0)
        {
            _msg.Warn("Некорректный номер заказа.");
            return;
        }

        var itemsRaw = ItemsRawTextBox.Text.Trim();
        var parsed = ParseItemsRaw(itemsRaw);
        if (parsed.Count == 0)
        {
            _msg.Warn("Заполните артикул(ы) заказа. Формат: PS001, 2, PS005, 1");
            return;
        }

        if (StatusCombo.SelectedItem is not OrderStatus status)
        {
            _msg.Warn("Выберите статус заказа.");
            return;
        }

        if (PickupCombo.SelectedItem is not PickupPoint pickup)
        {
            _msg.Warn("Выберите пункт выдачи.");
            return;
        }

        if (OrderDatePicker.SelectedDate is not DateTime od || DeliveryDatePicker.SelectedDate is not DateTime dd)
        {
            _msg.Warn("Выберите даты заказа и доставки.");
            return;
        }

        if (dd.Date < od.Date)
        {
            _msg.Warn("Дата доставки не может быть раньше даты заказа.");
            return;
        }

        if (!int.TryParse(ReceiveCodeTextBox.Text.Trim(), out var receiveCode) || receiveCode <= 0)
        {
            _msg.Warn("Код получения должен быть целым положительным числом.");
            return;
        }

        try
        {
            using var scope = _services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<PosudarushkaDbContext>();

            // Choose customer: for assignment imports orders are linked by FullName; for manual add/edit we'll assign current user.
            var customer = _session.User;
            if (customer == null)
            {
                // fallback: pick any client/manager/admin from DB
                customer = await db.Users.OrderBy(u => u.UserId).FirstAsync();
            }

            Order order;
            if (_orderId == null)
            {
                var exists = await db.Orders.AnyAsync(o => o.OrderNumber == orderNumber);
                if (exists)
                {
                    _msg.Warn("Заказ с таким номером уже существует.");
                    return;
                }

                order = new Order
                {
                    OrderNumber = orderNumber,
                    CustomerId = customer.UserId,
                    PickupPointId = pickup.PickupPointId,
                    OrderStatusId = status.OrderStatusId,
                    OrderDate = DateOnly.FromDateTime(od),
                    DeliveryDate = DateOnly.FromDateTime(dd),
                    ReceiveCode = receiveCode
                };
                db.Orders.Add(order);
            }
            else
            {
                order = await db.Orders.Include(o => o.Items).FirstAsync(o => o.OrderId == _orderId.Value);
                order.PickupPointId = pickup.PickupPointId;
                order.OrderStatusId = status.OrderStatusId;
                order.OrderDate = DateOnly.FromDateTime(od);
                order.DeliveryDate = DateOnly.FromDateTime(dd);
                order.ReceiveCode = receiveCode;
            }

            // Validate products and rebuild items
            var articles = parsed.Select(x => x.Article).Distinct().ToList();
            var products = await db.Products.Where(p => articles.Contains(p.Article)).ToListAsync();
            var byArticle = products.ToDictionary(p => p.Article, p => p);

            var missing = articles.Where(a => !byArticle.ContainsKey(a)).ToList();
            if (missing.Count > 0)
            {
                _msg.Error("Не найдены товары по артикулам: " + string.Join(", ", missing));
                return;
            }

            // 1. Revert stock logic (if editing, put old items back to shelf)
            if (_orderId != null)
            {
                // We need to fetch items again to be sure (already fetched in 'order' variable, but let's be safe)
                foreach (var item in order.Items)
                {
                    var p = await db.Products.FindAsync(item.ProductId);
                    if (p != null)
                    {
                        p.StockQty += item.Quantity; // Put back
                    }
                }
                
                // Clear items so we can re-add them clean
                order.Items.Clear();
            }

            // 2. Add new items and deduct stock
            foreach (var (art, qty) in parsed)
            {
                var product = byArticle[art];
                
                // Check stock
                if (product.StockQty < qty)
                {
                    throw new InvalidOperationException($"Недостаточно товара '{product.Name}' на складе.\nВ наличии: {product.StockQty}, требуется: {qty}");
                }

                product.StockQty -= qty; // Deduct from warehouse

                order.Items.Add(new OrderItem { ProductId = product.ProductId, Quantity = qty });
            }

            await db.SaveChangesAsync();

            DialogResult = true;
            Close();
        }
        catch (Exception ex)
        {
            _msg.Error($"Не удалось сохранить заказ.\n\n{ex.Message}");
        }
    }
}

