using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Posudarushka.App.Data;
using Posudarushka.App.Services;
using Posudarushka.App.ViewModels;

namespace Posudarushka.App.Views;

public partial class OrdersPage : Page
{
    private readonly IServiceProvider _services;
    private readonly CurrentSession _session;
    private readonly AppMessageBox _msg;

    public Visibility AdminOnlyVisibility => _session.IsAdmin ? Visibility.Visible : Visibility.Collapsed;
    public Visibility AdminOrManagerVisibility => _session.IsAdminOrManager ? Visibility.Visible : Visibility.Collapsed;

    private readonly ObservableCollection<OrderListItem> _items = [];

    public OrdersPage(IServiceProvider services)
    {
        _services = services;
        _session = services.GetRequiredService<CurrentSession>();
        _msg = services.GetRequiredService<AppMessageBox>();

        InitializeComponent();
        DataContext = this;

        OrdersList.ItemsSource = _items;
        Loaded += OrdersPage_Loaded;
    }

    private async void OrdersPage_Loaded(object sender, RoutedEventArgs e)
    {
        await ReloadAsync();
    }

    private async Task ReloadAsync()
    {
        try
        {
            using var scope = _services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<PosudarushkaDbContext>();

            var q = db.Orders
                .Include(o => o.OrderStatus)
                .Include(o => o.PickupPoint)
                .Include(o => o.Customer)
                .Include(o => o.Items).ThenInclude(i => i.Product)
                .AsNoTracking();

            // Clients see only their own orders
            if (!_session.IsAdminOrManager && _session.User != null)
            {
                q = q.Where(o => o.CustomerId == _session.User.UserId);
            }
            // Guests see nothing? Or maybe throw error? Let's assume Guests see nothing.
            else if (_session.Role == AppRole.Guest)
            {
                q = q.Where(o => false);
            }

            var orders = await q.OrderByDescending(o => o.OrderDate).ToListAsync();

            _items.Clear();
            foreach (var o in orders)
                _items.Add(new OrderListItem(o));
        }
        catch (Exception ex)
        {
            _msg.Error($"Не удалось загрузить заказы.\n\n{ex.Message}");
        }
    }

    private async void AddOrder_Click(object sender, RoutedEventArgs e)
    {
        if (!_session.IsAdminOrManager)
        {
            _msg.Warn("Добавление/редактирование заказов доступно только администратору и менеджеру.");
            return;
        }

        var wnd = new OrderEditWindow(_services, null);
        var ok = wnd.ShowDialog() == true;
        if (ok)
            await ReloadAsync();
    }

    private async void OrdersList_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (!_session.IsAdminOrManager)
            return;

        if (OrdersList.SelectedItem is not OrderListItem item)
            return;

        var wnd = new OrderEditWindow(_services, item.OrderId);
        var ok = wnd.ShowDialog() == true;
        if (ok)
            await ReloadAsync();
    }

    private async void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (!_session.IsAdmin) // STRICTLY ADMIN ONLY
        {
            _msg.Warn("Удаление заказов доступно только администратору.");
            return;
        }

        if (sender is not Button b || b.Tag is not int orderId)
            return;

        var ok = _msg.Confirm("Удалить выбранный заказ? Операция необратима.", "Удаление заказа");
        if (!ok) return;

        try
        {
            using var scope = _services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<PosudarushkaDbContext>();

            var o = await db.Orders
                .Include(o => o.Items)
                .FirstOrDefaultAsync(x => x.OrderId == orderId);
            if (o == null)
                return;

            // Вернуть товары на склад
            var productIds = o.Items.Select(i => i.ProductId).Distinct().ToList();
            var products = await db.Products.Where(p => productIds.Contains(p.ProductId)).ToListAsync();
            var prodDict = products.ToDictionary(p => p.ProductId);

            foreach (var item in o.Items)
            {
                if (prodDict.TryGetValue(item.ProductId, out var prod))
                {
                    prod.StockQty += item.Quantity;
                }
            }

            db.Orders.Remove(o);
            await db.SaveChangesAsync();

            await ReloadAsync();
        }
        catch (Exception ex)
        {
            _msg.Error($"Не удалось удалить заказ.\n\n{ex.Message}");
        }
    }
}

