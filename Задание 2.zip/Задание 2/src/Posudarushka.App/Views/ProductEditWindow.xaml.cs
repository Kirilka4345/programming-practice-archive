using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Win32;
using Posudarushka.App.Data;
using Posudarushka.App.Services;

namespace Posudarushka.App.Views;

public partial class ProductEditWindow : Window
{
    public static bool IsOpen { get; private set; }

    private readonly IServiceProvider _services;
    private readonly AppMessageBox _msg;

    private readonly int? _productId;
    private string? _selectedImageTempPath;
    private string? _oldImagePathRel;

    public string HeaderText => _productId == null ? "Добавление товара" : "Редактирование товара";

    public ProductEditWindow(IServiceProvider services, int? productId)
    {
        if (IsOpen)
            throw new InvalidOperationException("ProductEditWindow already open");

        IsOpen = true;
        _services = services;
        _msg = services.GetRequiredService<AppMessageBox>();
        _productId = productId;

        InitializeComponent();
        DataContext = this;

        Loaded += ProductEditWindow_Loaded;
        Closed += (_, _) => IsOpen = false;
    }

    private async void ProductEditWindow_Loaded(object sender, RoutedEventArgs e)
    {
        try
        {
            using var scope = _services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<PosudarushkaDbContext>();

            var categories = await db.Categories.AsNoTracking().OrderBy(x => x.Name).Select(x => x.Name).ToListAsync();
            var manufacturers = await db.Manufacturers.AsNoTracking().OrderBy(x => x.Name).Select(x => x.Name).ToListAsync();
            var suppliers = await db.Suppliers.AsNoTracking().OrderBy(x => x.Name).Select(x => x.Name).ToListAsync();

            CategoryCombo.ItemsSource = categories;
            ManufacturerCombo.ItemsSource = manufacturers;
            SupplierCombo.ItemsSource = suppliers;

            if (_productId == null)
            {
                IdTextBox.Text = "(авто)";
                SetPreviewFromRelativePath(null);
                return;
            }

            var p = await db.Products
                .Include(x => x.Supplier)
                .Include(x => x.Manufacturer)
                .Include(x => x.Category)
                .FirstOrDefaultAsync(x => x.ProductId == _productId.Value);
            if (p == null)
            {
                _msg.Error("Товар не найден.");
                DialogResult = false;
                Close();
                return;
            }

            IdTextBox.Text = p.ProductId.ToString(CultureInfo.InvariantCulture);
            ArticleTextBox.Text = p.Article;
            NameTextBox.Text = p.Name;
            CategoryCombo.Text = p.Category?.Name ?? "";
            ManufacturerCombo.Text = p.Manufacturer?.Name ?? "";
            SupplierCombo.Text = p.Supplier?.Name ?? "";
            UnitTextBox.Text = p.Unit;
            PriceTextBox.Text = p.PriceRub.ToString("0.##", CultureInfo.InvariantCulture);
            DiscountTextBox.Text = p.DiscountPercent.ToString("0.##", CultureInfo.InvariantCulture);
            StockTextBox.Text = p.StockQty.ToString(CultureInfo.InvariantCulture);
            DescriptionTextBox.Text = p.Description ?? "";

            _oldImagePathRel = p.ImagePath;
            SetPreviewFromRelativePath(p.ImagePath);
        }
        catch (Exception ex)
        {
            _msg.Error($"Не удалось загрузить форму.\n\n{ex.Message}");
        }
    }

    private void SetPreviewFromRelativePath(string? rel)
    {
        var baseDir = AppContext.BaseDirectory;
        var placeholder = Path.Combine(baseDir, "Assets", "picture.png");
        string path;
        if (string.IsNullOrWhiteSpace(rel))
            path = placeholder;
        else
        {
            path = Path.Combine(baseDir, rel.Replace('/', Path.DirectorySeparatorChar));
            if (!File.Exists(path))
                path = placeholder;
        }

        PreviewImage.Source = new BitmapImage(new Uri(path));
    }

    private void SelectPhoto_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog
        {
            Filter = "Изображения|*.png;*.jpg;*.jpeg;*.bmp|Все файлы|*.*",
            Title = "Выберите изображение товара"
        };

        if (dlg.ShowDialog(this) != true)
            return;

        try
        {
            var bmp = new BitmapImage();
            bmp.BeginInit();
            bmp.CacheOption = BitmapCacheOption.OnLoad;
            bmp.UriSource = new Uri(dlg.FileName);
            bmp.EndInit();

            if (bmp.PixelWidth > 300 || bmp.PixelHeight > 200)
            {
                _msg.Warn($"Изображение слишком большое: {bmp.PixelWidth}×{bmp.PixelHeight}.\nДопустимо: до 300×200 пикселей.");
                return;
            }

            _selectedImageTempPath = dlg.FileName;
            PreviewImage.Source = bmp;
        }
        catch (Exception ex)
        {
            _msg.Error($"Не удалось открыть изображение.\n\n{ex.Message}");
        }
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
        Close();
    }

    private async void Save_Click(object sender, RoutedEventArgs e)
    {
        var article = ArticleTextBox.Text.Trim();
        var name = NameTextBox.Text.Trim();
        var category = CategoryCombo.Text.Trim();
        var manufacturer = ManufacturerCombo.Text.Trim();
        var supplier = SupplierCombo.Text.Trim();
        var unit = UnitTextBox.Text.Trim();
        var desc = DescriptionTextBox.Text.Trim();

        if (string.IsNullOrWhiteSpace(article) || string.IsNullOrWhiteSpace(name))
        {
            _msg.Warn("Артикул и наименование — обязательные поля.");
            return;
        }

        if (string.IsNullOrWhiteSpace(category) || string.IsNullOrWhiteSpace(manufacturer) || string.IsNullOrWhiteSpace(supplier))
        {
            _msg.Warn("Категория, производитель и поставщик — обязательные поля.");
            return;
        }

        if (!decimal.TryParse(PriceTextBox.Text.Trim().Replace(',', '.'), NumberStyles.Number, CultureInfo.InvariantCulture, out var price) || price < 0)
        {
            _msg.Warn("Цена должна быть числом и не может быть отрицательной.");
            return;
        }

        if (!decimal.TryParse(DiscountTextBox.Text.Trim().Replace(',', '.'), NumberStyles.Number, CultureInfo.InvariantCulture, out var discount) || discount < 0 || discount > 99.99m)
        {
            _msg.Warn("Скидка должна быть числом от 0 до 99.99 (в процентах).");
            return;
        }

        if (!int.TryParse(StockTextBox.Text.Trim(), out var stock) || stock < 0)
        {
            _msg.Warn("Количество на складе должно быть целым числом и не может быть отрицательным.");
            return;
        }

        if (string.IsNullOrWhiteSpace(unit))
        {
            _msg.Warn("Единица измерения — обязательное поле.");
            return;
        }

        try
        {
            using var scope = _services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<PosudarushkaDbContext>();

            var cat = await db.Categories.FirstOrDefaultAsync(x => x.Name == category) ?? (await db.Categories.AddAsync(new Category { Name = category })).Entity;
            var man = await db.Manufacturers.FirstOrDefaultAsync(x => x.Name == manufacturer) ?? (await db.Manufacturers.AddAsync(new Manufacturer { Name = manufacturer })).Entity;
            var sup = await db.Suppliers.FirstOrDefaultAsync(x => x.Name == supplier) ?? (await db.Suppliers.AddAsync(new Supplier { Name = supplier })).Entity;

            Product p;
            if (_productId == null)
            {
                var exists = await db.Products.AnyAsync(x => x.Article == article);
                if (exists)
                {
                    _msg.Warn("Товар с таким артикулом уже существует. Артикул должен быть уникальным.");
                    return;
                }
                p = new Product
                {
                    Article = article,
                    Name = name,
                    Unit = unit,
                    PriceRub = price,
                    DiscountPercent = discount,
                    StockQty = stock,
                    Description = desc,
                    CategoryId = cat.CategoryId,
                    ManufacturerId = man.ManufacturerId,
                    SupplierId = sup.SupplierId
                };
                db.Products.Add(p);
            }
            else
            {
                p = await db.Products.FirstOrDefaultAsync(x => x.ProductId == _productId.Value)
                    ?? throw new InvalidOperationException("Product not found");

                // if article changed -> keep uniqueness
                if (!string.Equals(p.Article, article, StringComparison.OrdinalIgnoreCase))
                {
                    var exists = await db.Products.AnyAsync(x => x.Article == article && x.ProductId != p.ProductId);
                    if (exists)
                    {
                        _msg.Warn("Товар с таким артикулом уже существует. Артикул должен быть уникальным.");
                        return;
                    }
                }

                p.Article = article;
                p.Name = name;
                p.Unit = unit;
                p.PriceRub = price;
                p.DiscountPercent = discount;
                p.StockQty = stock;
                p.Description = desc;
                p.CategoryId = cat.CategoryId;
                p.ManufacturerId = man.ManufacturerId;
                p.SupplierId = sup.SupplierId;
            }

            // image save (optional)
            if (!string.IsNullOrWhiteSpace(_selectedImageTempPath))
            {
                var ext = Path.GetExtension(_selectedImageTempPath).ToLowerInvariant();
                if (ext is not (".png" or ".jpg" or ".jpeg" or ".bmp"))
                    ext = ".png";

                var outDir = Path.Combine(AppContext.BaseDirectory, "Images", "Products");
                Directory.CreateDirectory(outDir);
                var outFile = Path.Combine(outDir, $"{article}{ext}");

                File.Copy(_selectedImageTempPath, outFile, overwrite: true);
                p.ImagePath = $"Images/Products/{Path.GetFileName(outFile)}";
            }

            await db.SaveChangesAsync();

            // remove old image file if replaced and no longer referenced
            if (!string.IsNullOrWhiteSpace(_selectedImageTempPath) &&
                !string.IsNullOrWhiteSpace(_oldImagePathRel) &&
                _oldImagePathRel != p.ImagePath)
            {
                var stillUsed = await db.Products.AnyAsync(x => x.ImagePath == _oldImagePathRel && x.ProductId != p.ProductId);
                if (!stillUsed)
                {
                    var oldFull = Path.Combine(AppContext.BaseDirectory, _oldImagePathRel.Replace('/', Path.DirectorySeparatorChar));
                    if (File.Exists(oldFull))
                        File.Delete(oldFull);
                }
            }

            DialogResult = true;
            Close();
        }
        catch (Exception ex)
        {
            _msg.Error($"Не удалось сохранить товар.\n\n{ex.Message}");
        }
    }
}

