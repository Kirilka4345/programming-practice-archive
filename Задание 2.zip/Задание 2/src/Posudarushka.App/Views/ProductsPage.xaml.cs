using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Posudarushka.App.Data;
using Posudarushka.App.Services;
using Posudarushka.App.ViewModels;

namespace Posudarushka.App.Views;

public partial class ProductsPage : Page
{
    private readonly IServiceProvider _services;
    private readonly CurrentSession _session;
    private readonly AppMessageBox _msg;

    private readonly ObservableCollection<ProductListItem> _items = [];
    private readonly ICollectionView _view;
    private bool _uiReady;

    private string _search = "";
    private string _supplier = "Все поставщики";
    private int _sortMode = 0;

    public Visibility AdminOnlyVisibility => _session.Role == AppRole.Admin ? Visibility.Visible : Visibility.Collapsed;
    public Visibility ManagerOrAdminVisibility => _session.Role is AppRole.Manager or AppRole.Admin ? Visibility.Visible : Visibility.Collapsed;

    public ProductsPage(IServiceProvider services)
    {
        _services = services;
        _session = services.GetRequiredService<CurrentSession>();
        _msg = services.GetRequiredService<AppMessageBox>();

        // Important: during InitializeComponent XAML events (SelectionChanged/TextChanged) can fire.
        // Guard handlers until collection view is ready.
        _uiReady = false;

        InitializeComponent();

        _view = CollectionViewSource.GetDefaultView(_items);
        _view.Filter = Filter;
        ProductsList.ItemsSource = _view;

        DataContext = this;
        _uiReady = true;

        Loaded += ProductsPage_Loaded;
    }

    private async void ProductsPage_Loaded(object sender, RoutedEventArgs e)
    {
        await ReloadAsync();
    }

    private bool Filter(object obj)
    {
        if (obj is not ProductListItem p)
            return false;

        if (!string.IsNullOrWhiteSpace(_supplier) && _supplier != "Все поставщики" && p.Supplier != _supplier)
            return false;

        if (string.IsNullOrWhiteSpace(_search))
            return true;

        var s = _search.ToLowerInvariant();
        return (p.Article + " " + p.Name + " " + p.Category + " " + p.Manufacturer + " " + p.Supplier + " " + (p.Description ?? "") + " " + p.Unit)
            .ToLowerInvariant()
            .Contains(s);
    }

    private void ApplySort()
    {
        if (!_uiReady)
            return;
        _view.SortDescriptions.Clear();
        if (_sortMode == 1)
            _view.SortDescriptions.Add(new SortDescription(nameof(ProductListItem.StockQty), ListSortDirection.Ascending));
        else if (_sortMode == 2)
            _view.SortDescriptions.Add(new SortDescription(nameof(ProductListItem.StockQty), ListSortDirection.Descending));
    }

    private async Task ReloadAsync()
    {
        try
        {
            using var scope = _services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<PosudarushkaDbContext>();

            var products = await db.Products
                .Include(p => p.Supplier)
                .Include(p => p.Manufacturer)
                .Include(p => p.Category)
                .AsNoTracking()
                .ToListAsync();

            _items.Clear();
            foreach (var p in products)
                _items.Add(new ProductListItem(p));

            // Supplier filter list
            var suppliers = products.Select(p => p.Supplier?.Name).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().OrderBy(x => x).ToList();
            SupplierCombo.Items.Clear();
            SupplierCombo.Items.Add("Все поставщики");
            foreach (var s in suppliers)
                SupplierCombo.Items.Add(s!);
            SupplierCombo.SelectedIndex = 0;

            ApplySort();
            _view.Refresh();
        }
        catch (Exception ex)
        {
            _msg.Error($"Не удалось загрузить товары.\n\n{ex.Message}");
        }
    }

    private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (!_uiReady)
            return;
        _search = SearchTextBox.Text.Trim();
        _view.Refresh();
    }

    private void SupplierCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!_uiReady)
            return;
        _supplier = SupplierCombo.SelectedItem?.ToString() ?? "Все поставщики";
        _view.Refresh();
    }

    private void SortCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!_uiReady)
            return;
        _sortMode = SortCombo.SelectedIndex;
        ApplySort();
        _view.Refresh();
    }

    private async void AddProduct_Click(object sender, RoutedEventArgs e)
    {
        if (_session.Role != AppRole.Admin)
        {
            _msg.Warn("Добавление товаров доступно только администратору.");
            return;
        }

        if (ProductEditWindow.IsOpen)
        {
            _msg.Warn("Уже открыто окно редактирования товара. Закройте его перед открытием нового.");
            return;
        }

        var wnd = new ProductEditWindow(_services, null);
        var ok = wnd.ShowDialog() == true;
        if (ok)
            await ReloadAsync();
    }

    private async void ProductsList_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (_session.Role != AppRole.Admin)
            return;

        if (ProductsList.SelectedItem is not ProductListItem item)
            return;

        if (ProductEditWindow.IsOpen)
        {
            _msg.Warn("Уже открыто окно редактирования товара. Закройте его перед открытием нового.");
            return;
        }

        var wnd = new ProductEditWindow(_services, item.ProductId);
        var ok = wnd.ShowDialog() == true;
        if (ok)
            await ReloadAsync();
    }

    private async void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (_session.Role != AppRole.Admin)
            return;

        if (sender is not Button b || b.Tag is not int productId)
            return;

        var ok = _msg.Confirm("Удалить выбранный товар? Операция необратима.", "Удаление товара");
        if (!ok) return;

        try
        {
            using var scope = _services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<PosudarushkaDbContext>();

            var inOrder = await db.OrderItems.AnyAsync(oi => oi.ProductId == productId);
            if (inOrder)
            {
                _msg.Warn("Нельзя удалить товар, который присутствует в заказе.");
                return;
            }

            var p = await db.Products.FirstOrDefaultAsync(x => x.ProductId == productId);
            if (p == null)
                return;

            db.Products.Remove(p);
            await db.SaveChangesAsync();

            await ReloadAsync();
        }
        catch (Exception ex)
        {
            _msg.Error($"Не удалось удалить товар.\n\n{ex.Message}");
        }
    }
}

