using System.IO;
using System.Windows;
using System.Windows.Navigation;
using Microsoft.Extensions.DependencyInjection;
using Posudarushka.App.Services;

namespace Posudarushka.App.Views;

public partial class ShellWindow : Window
{
    private readonly IServiceProvider _services;
    private readonly CurrentSession _session;

    public string UserDisplay => _session.DisplayName;
    public string LogoPath { get; }

    public string PageTitle { get; set; } = "Товары";

    public ShellWindow(IServiceProvider services)
    {
        _services = services;
        _session = services.GetRequiredService<CurrentSession>();
        LogoPath = Path.Combine(AppContext.BaseDirectory, "Assets", "Logo.png");

        InitializeComponent();
        DataContext = this;

        OrdersButton.Visibility = _session.Role is AppRole.Manager or AppRole.Admin
            ? Visibility.Visible
            : Visibility.Collapsed;

        MainFrame.Navigated += Frame_Navigated;
        NavigateToProducts();
    }

    private void Frame_Navigated(object? sender, NavigationEventArgs e)
    {
        if (e.Content is FrameworkElement fe && fe.Tag is string title && !string.IsNullOrWhiteSpace(title))
            PageTitle = title;
        else
            PageTitle = "Посударушка";
        DataContext = null;
        DataContext = this;
    }

    private void Products_Click(object sender, RoutedEventArgs e) => NavigateToProducts();
    private void Orders_Click(object sender, RoutedEventArgs e) => NavigateToOrders();

    private void NavigateToProducts() =>
        MainFrame.Navigate(new ProductsPage(_services) { Tag = "Товары" });

    private void NavigateToOrders()
    {
        if (_session.Role is not (AppRole.Manager or AppRole.Admin))
        {
            _services.GetRequiredService<AppMessageBox>().Warn("Доступ к заказам разрешён только менеджеру и администратору.");
            return;
        }
        MainFrame.Navigate(new OrdersPage(_services) { Tag = "Заказы" });
    }

    private void Back_Click(object sender, RoutedEventArgs e)
    {
        if (MainFrame.CanGoBack)
            MainFrame.GoBack();
    }

    private void Logout_Click(object sender, RoutedEventArgs e)
    {
        var ok = _services.GetRequiredService<AppMessageBox>().Confirm("Выйти из текущей учётной записи?");
        if (!ok) return;

        _session.SetGuest();

        var login = new LoginWindow(_services);
        Application.Current.MainWindow = login;
        login.Show();
        Close();
    }
}

